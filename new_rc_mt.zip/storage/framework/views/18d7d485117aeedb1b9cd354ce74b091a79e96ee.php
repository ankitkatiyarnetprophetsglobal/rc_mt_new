
<?php $__env->startSection('page_specific_css'); ?>
    
    
    <link rel="stylesheet" href="<?php echo e(asset('public/front/css/plugin/bootstrap-multiselect.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/front/css/plugin/bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <span class="spinner"></span>
        <form class="template_management">
            <div class="row justify-content-md-end justify-content-center my-3">
                <div class="col-lg-12 col-md-12 col-12">

                    <div class="row align-items-center mb-2">
                        <div class="col-10 col">
                            <h3>
                               Add New Templates
                            </h3>
                        </div>
                        <div class="col-2">
                            <a class="btn btn-outline-success add_more add_btn" href="javascript:void(0)">
                                <i class="fa-solid fa-plus"></i> 
                                ADD
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="rc_forms input-form" id="template_management_form_container">
                <div class="row_0">
                    <div class="row p-0 m-0 align-items-center">
                        <div class=" col-md-auto col-12 form-fields mb-4 ">
                            <fieldset>
                                <legend class="form_field_name"><span>TITLE/NAME OF TEMPLATE</span></legend>
                                <input type="text" class="form-control template_name_0" id="template_name[0][template_name]"
                                    name="monthly_monitoring[0][template_name]" aria-describedby="template name" autocomplete="off">                            
                            </fieldset>
                            <span class="text-danger error_template_name_0"></span>
                        </div>
                        <div class=" col-md-auto col-12 form-fields mb-4  ">
                            <fieldset>
                                <legend class="form_field_name"><span>FROM  DATE</span></legend>
                                <input type="text" class="form-control from_date_0 add_from_date_0" id="monthly_monitoring[0][from_date]"
                                    name="monthly_monitoring[0][from_date]" aria-describedby="from date" autocomplete="off">                            
                            </fieldset>
                            <span class="text-danger error_from_date_0"></span>
                        </div>
                        <div class=" col-md-auto col-12 form-fields mb-4  ">
                            <fieldset>
                                <legend class="form_field_name"><span>TO  DATE</span></legend>
                                <input type="text" class="form-control to_date_0 add_to_date_0" id="monthly_monitoring[0][to_date]"
                                    name="monthly_monitoring[0][to_date]" aria-describedby="to date" autocomplete="off">                           
                            </fieldset>
                            <span class="text-danger error_to_date_0"></span>
                        </div>
                        <div class=" col-md-auto col-12 form-fields mb-4  ">
                            <fieldset>
                                <legend class="form_field_name"><span >REGIONAL CENTER</span></legend>
                                <?php $rc_details = getRcList(); ?>
                                <select  class="form-select regional_center_0 monthly_monitoring_regional_center_0" id="monthly_monitoring[0][regional_center]" name="monthly_monitoring[0][regional_center][]" aria-label="regional center" multiple="multiple" autocomplete="off" >
                                    <?php $__currentLoopData = $rc_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <option  value="<?php echo e($val->user_id); ?>"><?php echo e($val->user_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>                            
                            </fieldset>
                            <span class="text-danger error_regional_center_0"></span>
                        </div>
                        <div class="col-md-auto col-12 form-fields mb-4  ">
                            <fieldset>
                                <legend class="form_field_name"><span>TEMPLATE</span></legend>
                                <select class="form-select template_0 monthly_monitoring_template_0" id="monthly_monitoring[0][template]" name="monthly_monitoring[0][template][]" aria-label="regional center" multiple="multiple" autocomplete="off">
                                    <?php $__currentLoopData = $template_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a_key => $a_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($a_key); ?>"><?php echo e($a_value); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>                            
                            </fieldset>
                            <span class="text-danger error_template_0"></span>
                        </div>
                        <div class="col-md-auto col-12 form-fields mb-4  ">
                            <fieldset>
                                <legend class="form_field_name"><span>CATEGORIES</span></legend>
                                  <select class="form-select categories_0 monthly_monitoring_categories_0" id="monthly_categories" name="monthly_monitoring[0][categories][]" multiple="multiple" autocomplete="off">
                                    <option value="1">One time</option>                               
                                    <option value="2">Multiple time</option>                               
                                  </select>                            
                            </fieldset>
                            <span class="text-danger error_categories_0"></span>
                        </div>
                        <div class="col-md-auto col-12 mb-4 delete-icon">
                            <a href="#" class="btn btn-outline-danger remove_btn" data-id="0"><i class="fa-solid fa-trash-can"></i></a>
                        </div>
                    </div>
                </div>                
            </div>

            <div class="col-12 ">
                <button type="submit" class="btn btn-warning px-md-4 inputDisabled">Save</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_specific_js'); ?>
   
    <script src="<?php echo e(asset('public/front/js/templatemanagement/templatemanagement.js')); ?>"></script>   
    <script src="<?php echo e(asset('public/front/js/templatemanagement/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/front/js/templatemanagement/bootstrap-multiselect.js')); ?>"></script>

    <script>
    
        selected_template = []; 
        selected_regional_center = [];

        $(document).ready(function() {
            
            $('.monthly_monitoring_regional_center_0').multiselect({
                includeSelectAllOption: true,
            });

            $('.monthly_monitoring_template_0').multiselect({
                includeSelectAllOption: true,
            });

            $('.monthly_monitoring_categories_0').multiselect({
                includeSelectAllOption: true,
            });
            
        });

    $(document).ready(function(){
        
        // $(".add_from_date_0").datepicker({
        //     // dateFormat : "dd-mm-yy",
        //     onSelect: function (selected,evnt) {
                
        //         var dt = new Date(selected);
        //         dt.setDate(dt.getDate() + 1);
        //         $(".add_to_date_0").datepicker("option", "minDate", dt);
                
        //     }
        // });

        // $(".add_to_date_0").datepicker({
        //     // dateFormat : "dd-mm-yy",
        //     onSelect: function (selected) {
        //         var dt = new Date(selected);
        //         dt.setDate(dt.getDate() - 1);
        //         $(".add_from_date_0").datepicker("option", "maxDate", dt);
        //     }
        // });


        $(function(){
            
            $(".add_to_date_0").datepicker({ dateFormat: 'dd-mm-yy' });
            
            $(".add_from_date_0").datepicker({ dateFormat: 'dd-mm-yy' }).bind("change",function(){
                var minValue = $(".add_from_date_0").val();
                minValue = $.datepicker.parseDate("dd-mm-yy", minValue);
                minValue.setDate(minValue.getDate()+1);
                $(".add_to_date_0").datepicker( "option", "minDate", minValue );
            })
        });

    });

    function getProjectTitle(selected_template){
            
            var template = '';
            
            <?php $__currentLoopData = $template_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_key => $p_val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
            if(jQuery.inArray("<?php echo e($p_key); ?>", selected_template) == -1){
                template += '<option value="<?php echo e($p_key); ?>"><?php echo e($p_val); ?></option>';
            }
        
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            return template;
        }
    
    function get_regional_center(selected_regional_center){
            
            var regional_center = '';
            
            <?php $__currentLoopData = $rc_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_key => $p_val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
            if(jQuery.inArray("<?php echo e($p_val->user_id); ?>", selected_regional_center) == -1){
                regional_center += '<option value="<?php echo e($p_val->user_id); ?>"><?php echo e($p_val->user_name); ?></option>';
            }
        
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            return regional_center;
        }

        jQuery(function($){
            $(document).ajaxSend(function() {
                $("#overlay").fadeIn(300);　
            });
                    
            $('#button').click(function(){
                $.ajax({
                type: 'GET',
                success: function(data){
                    console.log(data);
                }
                }).done(function() {
                setTimeout(function(){
                    $("#overlay").fadeOut(300);
                },500);
                });
            });	
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rc_mt\resources\views/admin/templatesMonitoring/create.blade.php ENDPATH**/ ?>