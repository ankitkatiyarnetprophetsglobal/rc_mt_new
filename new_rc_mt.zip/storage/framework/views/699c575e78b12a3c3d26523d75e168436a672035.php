
<?php $__env->startSection('page_specific_css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/front/themes/css/jquery.dataTables.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-md-end justify-content-center my-3">
            <div class="col-lg-12 col-md-12 col-12">
                <div class="row justify-content-between align-items-center">
                    <div class="col-auto my-2">
                        <h3>
                            TEMPLATES
                        </h3>
                    </div>
                    <?php if(Session::get('role_details')->id == 1): ?>
                        <div class="col-auto my-2">
                            <a class="btn btn-outline-success" href="<?php echo e(route('temp.manage.create')); ?>">
                                <i class="fa-solid fa-plus"></i> ADD
                            </a>
                        </div>
                    <?php endif; ?>
                    <?php if(Session::has('message')): ?>
                        <div class="alert alert-success">
                            <strong>Success!</strong> <?php echo e(Session::get('message')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(Session::has('error_message')): ?>
                        <div class="alert alert-danger">
                            <strong>Error!</strong> <?php echo e(Session::get('error_message')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="row justify-content-lg-end justify-content-md-end justify-content-center">
                    <form class="row justify-content-end"  id="filter_form">
                       
                        <div class="col-lg-auto col-md-6 col-6">
                            <select class="form-select temp_select_input" name="select_temp"
                                aria-label="Default select example">
                                <option value="" selected disabled>Select Template</option>
                                <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k_t => $v_t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e(encode5t($k_t)); ?>"><?php echo e($v_t); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-lg-auto col-md-4 col-4">
                            
                            <select class="form-select rc_select_input" name="select_rc"
                                aria-label="Default select example">
                                <option value="" selected disabled>Select Regional Center</option>
                                <?php $__currentLoopData = $rc_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r_key => $r_val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e(encode5t($r_val->user_id)); ?>"><?php echo e($r_val->user_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-lg-auto col-md-2 col-4">
                            <a class="btn btn-outline-success search_btn" href="javascript::void(0)">
                                SEARCH
                            </a>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <div class="dashboard align-middle manageTable ">

        <div class="table-responsive manageTable">
            <table class="table table-bordered table-hover manageTable" id="template_table">
                <thead>
                    <tr class="dashboard-heading">
                        <th scope="col">S.No</th>
                        <th scope="col">TITLE/NAME OF TEMPLATE</th>
                        <th scope="col">DURATION</th>
                        <th scope="col">REGIONAL CENTER</th>
                        <th scope="col">STATUS</th>
                        <th scope="col">ACTION</th>


                    </tr>
                </thead>
                <tbody class="table-group-divider">

                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td scope="row "><?php echo e($key + 1); ?></td>
                            <td><a href="<?php echo e(url('admin/template-management/template-wise-regional-center/'.encode5t($value->id))); ?>"><span
                                        class="text-decoration-underline"><?php echo e($value->name ?? ''); ?></span></a></td>
                            <td><?php echo e(date('d-m-Y', strtotime($value->from_date))); ?> -
                                <?php echo e(date('d-m-Y', strtotime($value->to_date))); ?></td>
                            <td>
                                <button type="button" class="border-0" data-bs-toggle="modal"
                                    data-bs-target="#staticBackdrop_<?php echo e($key); ?>">
                                    <img src="<?php echo e(asset('public/front/themes/images/eye-fill.svg')); ?>" alt="">
                                </button>

                                <!-- Modal -->
                                <div class="modal fade" id="staticBackdrop_<?php echo e($key); ?>" data-bs-backdrop="static"
                                    data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel"
                                    aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header border-0">

                                                <button type="button" class="btn-close border-0" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body ">
                                                <table class="table text-start table-bordered">
                                                    <thead class="dashboard-heading">
                                                        <tr>
                                                            <th scope="col">S.No</th>
                                                            <th scope="col">NAME OF THE REGIONAL CENTER</th>

                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $value->tempForRc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr class="border-0">
                                                                <th scope="row" class="modal-border">
                                                                    <?php echo e($k + 1); ?></th>
                                                                <td colspan="2" class="border-0">
                                                                    <?php $data = getRcDetails($val->rc_id); ?>
                                                                    <?php echo e($data->user_name ?? ''); ?>

                                                                </td>

                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </tbody>
                                                </table>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                            </td>
                            <td>
                                <?php if($value->to_date < date('Y-m-d')): ?>
                                    <div class="red_outline">EXPIRED</div>
                                <?php elseif($value->from_date > date('Y-m-d')): ?>
                                    <div class="yellow_outline">UPCOMING</div>
                                <?php else: ?>
                                    <div class="green_outline">ACTIVE</div>
                                <?php endif; ?>

                            </td>
                            <td>
                                <?php if(Session::get('role_details')->id == 1): ?>
                                <div class="d-flex justify-content-around align-items-center">
                                    <div>
                                        <button type="button" class="border-0">
                                            <div>
                                                <a href="<?php echo e(route('temp.manage.edit', encode5t($value->id))); ?>"
                                                    class="actionbtn">
                                                    <img src="<?php echo e(asset('public/front/themes/images/edit.svg')); ?>"
                                                        alt=""></i>
                                                    <div>EDIT</div>
                                                </a>
                                            </div>
                                        </button>
                                    </div>
                                    <div class="vl"></div>
                                    <div>
                                        <div><button type="button" class="border-0 delete_temp"
                                                data-id="<?php echo e($value->id); ?>"><img
                                                    src="<?php echo e(asset('public/front/themes/images/delete.svg')); ?>" alt="">
                                                <div>DELETE</div>
                                            </button>
                                        </div>

                                    </div>
                                </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                </tbody>
            </table>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_specific_js'); ?>
    <script src="<?php echo e(asset('public/front/themes/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/front/js/templatemanagement/template_filter.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('#template_table').DataTable({

            });
            $('.delete_temp').on('click', function() {
                let id = $(this).data("id");
                $.ajax({
                    method: "GET",
                    url: baseurl + "/admin/template-management/deleteById/" + id,
                    success: function(response) {
                        if (response.status == true) {
                            swal("Message", response.message, "success");
                            window.location.href = baseurl + "/admin/template-management/index";
                        } else {
                            swal("Message", response.message, "error");
                        }
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rc_mt\resources\views/admin/templatesMonitoring/index.blade.php ENDPATH**/ ?>