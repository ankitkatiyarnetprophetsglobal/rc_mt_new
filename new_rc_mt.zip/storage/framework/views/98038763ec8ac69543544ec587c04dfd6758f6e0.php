
<?php $__env->startSection('page_specific_css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-md-end justify-content-center my-3 align-items-center">
            <div class="row">
                <div class="col-lg-4 col-md-3 col-12 text-start ">
                    <div class="row justify-content-center">
                        <div class="month_title text-center">
                            
                            
                            
                            <?php $data = getRcDetails($select_rc_id); ?>
                            <?php echo e($data->user_name ?? ''); ?>

                        </div>
                        <div class="yellow_hl my-2"></div>
                    </div>
                </div>
                <div class="col-lg-8 col-md-9 col-12">
                    <div class="row justify-content-end align-items-center">
                        <form class="row justify-content-end" method="POST" id="filter_form" action="javascript::void(0)">
                            <?php echo csrf_field(); ?>
                            <div class="col-auto">
                                <select class="form-select temp_select_input" name="select_temp"
                                    aria-label="Default select example">
                                    <option value="" selected disabled>Select Template</option>
                                    <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k_t => $v_t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e(encode5t($k_t)); ?>"
                                            <?php if($k_t == $select_temp->id): ?> selected <?php endif; ?>><?php echo e($v_t); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-auto">
                                
                                <select class="form-select rc_select_input" name="select_rc"
                                    aria-label="Default select example">
                                    <option value="" selected disabled>Select Regional Center</option>
                                    <?php $__currentLoopData = $rc_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e(encode5t($val->user_id)); ?>"
                                            <?php echo e($val->user_id == $select_rc_id ? 'selected' : ''); ?>><?php echo e($val->user_name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-auto">
                                <a class="btn btn-outline-success search_btn" href="javascript::void(0)">
                                    SEARCH
                                </a>
                                
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
        <div class="dashboard align-middle ">

            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr class="dashboard-heading">
                            <th scope="col">S.No</th>
                            <th scope="col">MANAGE</th>

                            <th scope="col">STATUS</th>
                            <th scope="col">ACTION</th>



                        </tr>
                    </thead>
                    <tbody class="table-group-divider">

                        <?php $__currentLoopData = $template_accessible->tempSection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($key + 1); ?></th>
                                <td>
                                    <?php if(Session::get('role_details')->id == 1 ||
                                        strtotime($template_accessible->to_date) < strtotime(date('Y-m-d', time()))): ?>
                                        <a href="javascript:void(0)"><span
                                                class="text-decoration-underline"><?php echo e($value->section->name ?? ''); ?></span></a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route($value->section->route, encode5t($select_temp->id))); ?>"><span
                                                class="text-decoration-underline"><?php echo e($value->section->name ?? ''); ?></span></a>
                                    <?php endif; ?>
                                </td>
                                <td>
                                   <?php if(strtotime($template_accessible->to_date) < strtotime(date('Y-m-d', time()))): ?> 
                                   <div class="red_outline">EXPIRED</div>
                                   <?php else: ?> 
                                   <?php if($value->section->id == 1): ?>
                                   <?php if($infra_work): ?>
                                       <div class="green_outline">COMPLETE</div>
                                   <?php else: ?>
                                       <div class="red_outline">INCOMPLETE</div>
                                   <?php endif; ?>
                               <?php elseif($value->section->id == 2): ?>
                                   <?php if($finance): ?>
                                       <div class="green_outline">COMPLETE</div>
                                   <?php else: ?>
                                       <div class="red_outline">INCOMPLETE</div>
                                   <?php endif; ?>
                               <?php elseif($value->section->id == 3): ?>
                                   <?php if($procurement): ?>
                                       <div class="green_outline">COMPLETE</div>
                                   <?php else: ?>
                                       <div class="red_outline">INCOMPLETE</div>
                                   <?php endif; ?>
                               <?php elseif($value->section->id == 4): ?>
                                   <?php if($miscellaneous): ?>
                                       <div class="green_outline">COMPLETE</div>
                                   <?php else: ?>
                                       <div class="red_outline">INCOMPLETE</div>
                                   <?php endif; ?>
                               <?php else: ?>
                                   <div class="red_outline">INCOMPLETE</div>
                               <?php endif; ?>

                                   <?php endif; ?>

                                </td>
                                <td>
                                    <div class="d-flex justify-content-around align-items-center">
                                        <div>
                                            <div><button type="button" class="border-0 eye-view"><img
                                                        src="<?php echo e(asset('public/front/themes/images/eye-fill-rc.svg')); ?>"
                                                        alt=""></button></div>
                                            <div>VIEW</div>
                                        </div>
                                        <?php if(Session::get('role_details')->id != 1  &&
                                        strtotime($template_accessible->to_date) > strtotime(date('Y-m-d', time()))): ?>
                                            <div class="vl"></div>
                                            <div>


                                                <a href="<?php echo e(route($value->section->route, encode5t($select_temp->id))); ?>"
                                                    class="text-decoration-none">
                                                    <div><button type="button" class="border-0"><img
                                                                src="<?php echo e(asset('public/front/themes/images/edit.svg')); ?>"
                                                                alt=""></button></div>
                                                    <div>EDIT</div>
                                                </a>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_specific_js'); ?>
    <script src="<?php echo e(asset('public/front/js/templatemanagement/template_filter.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rc_mt\resources\views/admin/templatesMonitoring/rc_template_dashboard.blade.php ENDPATH**/ ?>