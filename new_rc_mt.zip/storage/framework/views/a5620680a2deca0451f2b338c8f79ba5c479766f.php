
<?php $__env->startSection('page_specific_css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/front\css\plugin\jquery-ui.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="manageTable">
       
        <div class="alert alert-danger error_message d-none">
            
        </div>
        
        
        <div class="d-flex justify-content-between flex-wrap align-items-center">
            <div class="d-flex "> 
                <a class="me-3" href="<?php echo e(route('procurement.service.index')); ?>"><img src="<?php echo e(asset('public/front\themes\svg\arrow-left-circle.svg')); ?>" alt="">
                </a>
                <h3 >Edit Procurement Service Title / Details</h3></div>
           </div>
        <div class="table-responsive mt-3">
            <form class="infra_master" action="<?php echo e(route('procurement.service.update')); ?>" method="POST">
                <?php echo csrf_field(); ?>
            <table class="table table-bordered pt-2">
                <thead>
                    <tr>
                        <th>SN.NO</th>
                        <th>Title / Details</th>
                        <th>Expiry date of existing contract</th>
                        <th>Existing contract value</th>
                        <th>Status</th>
                    </tr>
                </thead>
                
                <tbody id="multiple_infra_form_container">
                    
                        <tr class="row_0">
                            <td>1</td>
                            <td>
                                <input type="hidden" name="id" value ="<?php echo e($data->id); ?>">
                                <input type="text" name="title" class="form-control" placeholder="Title / Details" value="<?php echo e(old('title',$data->title)); ?>" autocomplete="off">
                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                            <td>
                               
                                <input type="text" name="expiry_date_of_existing_contract" class="form-control expiry_date_of_existing_contract" placeholder="dd-mm-yyyy" value="<?php echo e(old('expiry_date_of_existing_contract',date('d-m-Y',strtotime($data->expiry_date_of_existing_contract)))); ?>" autocomplete="off">
                                <?php $__errorArgs = ['expiry_date_of_existing_contract'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                            <td>
                               
                                <input type="text" name="existing_contract_value" class="form-control existing_contract_value" placeholder="Title / Details" value="<?php echo e(old('existing_contract_value',$data->existing_contract_value)); ?>" autocomplete="off">
                                <?php $__errorArgs = ['existing_contract_value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                            <td>
                               
                                <select class="form-control" name ="status" autocomplete="off">
                                    <option disabled> Select Status </option>
                                    
                                    <option value="1" <?php echo e(old('status',$data->status) == '1' ? 'selected' : ''); ?>><?php echo e(__('Active')); ?></option>
                                    <option value="0" <?php echo e(old('status',$data->status) == '0' ? 'selected' : ''); ?>><?php echo e(__('In-Active')); ?></option>
                                   
                                </select>
                                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                            
                        </tr>
                   
                    
                </tbody>
                <tr>
                    <td colspan="6"class="text-end">
                     <button type="submit" class="btn btn-warning px-md-4">Update</button>
 
                    </td>
                    </tr>
                
            
            </table>
        </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_specific_js'); ?>
<script src="<?php echo e(asset('public/front\js\plugin\jquery-ui.js')); ?>"></script>
<script>
    $(document).ready(function(){
        
        $(".expiry_date_of_existing_contract").datepicker({
                 slideDown: true,
                dateFormat: "dd-mm-yy",
              });
    })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rc_mt\resources\views/front/pages/masters/procurement_service/edit.blade.php ENDPATH**/ ?>