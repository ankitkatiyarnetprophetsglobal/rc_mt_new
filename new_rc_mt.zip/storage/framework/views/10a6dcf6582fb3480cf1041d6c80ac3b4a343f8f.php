
<?php $__env->startSection('page_specific_css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/front/themes/css/jquery.dataTables.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="dashboard-monthly">
        <div class="container">
            <div class="row justify-content-between align-items-center">
                <div class="col-auto my-2">
                    <h3>
                        Template Wise RC
                    </h3>
                </div>
                <div class="col-auto my-2">
                    <a class="btn btn-outline-success" href="<?php echo e(route('temp.manage.create')); ?>">
                        <i class="fa-solid fa-plus"></i> ADD
                    </a>
                    
                </div>
            </div>
            <div class="row justify-content-lg-end justify-content-md-end justify-content-center mb-2">
                <form class="row justify-content-end" method="POST" id="filter_form" action="javascript::void(0)">
                    <?php echo csrf_field(); ?>
                    <div class="col-lg-auto col-md-6 col-6">
                        <select class="form-select temp_select_input" name="select_temp"
                            aria-label="Default select example">
                            <option value="" selected disabled>Select Template</option>
                            <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k_t => $v_t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e(encode5t($k_t)); ?>" <?php if($k_t == $select_temp->id): ?> selected <?php endif; ?>><?php echo e($v_t); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-lg-auto col-md-4 col-4">
                        <select class="form-select rc_select_input" name="select_rc"
                            aria-label="Default select example">
                            <option value="" selected disabled>Select Regional Center</option>
                            <?php $__currentLoopData = $rc_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r_key => $r_val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e(encode5t($r_val->user_id)); ?>"><?php echo e($r_val->user_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-lg-auto col-md-2 col-4">
                        <a class="btn btn-outline-success search_btn" href="javascript::void(0)">
                            SEARCH
                        </a>
                        
                    </div>
                </form>
            </div>
            <div class="dashboard align-middle manageTable ">

                <div class="table-responsive">
                    <table class="table table-bordered table-hover manageTable" id="temp_wise_rc">
                        <thead>
                            <tr class="dashboard-heading">
                                <th scope="col">S.No</th>
                                <th scope="col">NAME OF THE REGIONAL CENTER</th>
                                <th scope="col">STATUS</th>
                                
                            </tr>
                        </thead>
                        <tbody class="table-group-divider">
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                
                                <td><?php echo e($key+1); ?></td>
                                <td>
                                    
                                    <a href="<?php echo e(url('admin/template-management/template-of-regional-center/'.encode5t($value->rc_id).'/'.encode5t($select_temp->id))); ?>">
                                        <span class="text-decoration-underline">
                                            
                                            
                                            <?php $data = getRcDetails($value->rc_id); ?>
                                                <?php echo e($data->user_name ?? ''); ?>

                                        </span>
                                    </a>
                                </td>


                                <td>
                                    
                                <?php $__currentLoopData = $value->infraWork; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                   <?php if($val->created_by == $value->rc_id): ?>
                                     <?php if($val->form_status == 1): ?>
                                    <div class="green_outline">Complete</div>
                                    <?php else: ?>
                                    <div class="red_outline">In-Complete</div>
                                    <?php endif; ?>
                                   <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_specific_js'); ?>
    <script src="<?php echo e(asset('public/front/themes/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/front/js/templatemanagement/template_filter.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('#temp_wise_rc').DataTable({});
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rc_mt\resources\views/admin/templatesMonitoring/template_rc.blade.php ENDPATH**/ ?>