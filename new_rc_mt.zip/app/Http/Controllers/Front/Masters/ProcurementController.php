<?php

namespace App\Http\Controllers\Front\Masters;

use App\Http\Controllers\Controller;
use App\Models\Masters\ProcurementMaster;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
class ProcurementController extends Controller
{
    public function index()
  {
    try {
      $data = ProcurementMaster::get();
      return view('front.pages.masters.procurement.index', ['data' => $data]);
    } catch (\Exception $ex) {
      $message = 'Somthing went wrong, Please try again...';
      return view('404_page', ['message' => $message, 'error_code' => 400]);
    }
  }

  public function create()
  {
    try {
     return view('front.pages.masters.procurement.create');
    } catch (\Exception $ex) {
      $message = 'Somthing went wrong, Please try again...';
      return view('404_page', ['message' => $message, 'error_code' => 400]);
    }
  }
  public function store(Request $request)
  {
    
    
    $validator = Validator::make($request->all(), [
      "procurement.*.title"    => ['required','regex:/^(?!\d+$)(?:[a-zA-Z0-9][a-zA-Z0-9 @,_&$]*)?$/', Rule::unique('procurement_master')->where(function ($query) use ($request) {
        foreach($request->procurement as $value){
        $query->where('title',$value['title'])->where('deleted_at',null);
      }
      return $query;
      })],
      "procurement.*.type"    => "required",
      
      
    ], [
      'procurement.*.type.required' => 'Please Select Type.',
      'procurement.*.title.required' => 'Please Enter Title',
      'procurement.*.title.unique' => 'The Project Title Has Already Been Taken.',
      
    ]);
    if ($validator->fails()) {

      return response()->json(['success' => false, 'message' => $validator->errors()->first()]);
    }
    
    try {

      foreach ($request->procurement as $key => $value) {
        $procurement = new ProcurementMaster();
        $procurement->type = $value['type'];
        $procurement->title = $value['title'];
        $procurement->status = true;
        $procurement->created_by = Session::get('user')->user_id;
        $procurement->save();
      }
      Session::flash('message', 'Record Created.');
      return response()->json(['success' => true, 'message' => 'Data added successfully!']);
    } catch (\Exception $ex) {
        return response()->json(['success' => false, 'error_message' => 'Somthing went wrong.']);
    }
  }

  public function edit($id)
  {
    
    try {
      $procurement = ProcurementMaster::findOrFail(decode5t($id));
     return view ('front.pages.masters.procurement.edit', ['data' => $procurement]);
    } catch (\Exception $ex) {
      $message = 'Somthing went wrong, Please try again...';
      return view('404_page', ['message' => $message, 'error_code' => 400]);
    }
  }

  public function update(Request $request){
    
   $request->validate([
      "type"    => "required",
      "title"    => ['required','regex:/^(?!\d+$)(?:[a-zA-Z0-9][a-zA-Z0-9 @,_&$]*)?$/', Rule::unique('procurement_master')->where(function ($query) use ($request) {
        
        $query->where('title',$request->title)->where('deleted_at',null);
      
      return $query;
      })->ignore($request->id)]
    ]);
    
    try {
     $procurement = ProcurementMaster::findOrFail($request->id);
     $procurement->type = $request->type;
     $procurement->title = $request->title;
     $procurement->updated_by = Session::get('user')->user_id;
     $procurement->status = $request->status;
     $procurement->save();
        Session::flash('message', 'Record Updated.');
        return redirect()->route('procurement.index');
    } catch (\Exception $ex) {
      $message = 'Somthing went wrong, Please try again...';
      return view('404_page', ['message' => $message, 'error_code' => 400]);
    }
  }
  public function delete($id)
  {
    
    $user_id = Session::get('user')->user_id;;
    try {
      $procurement = ProcurementMaster::findOrFail(decode5t($id));
      if($procurement->delete()){
        $procurement->deleted_by = $user_id;
        $procurement->save();
       
      Session::flash('message', 'Record Deleted.');
      return redirect()->route('procurement.index');
      }
      Session::flash('error_message', 'Somthing went wrong, please try again...');
      return redirect()->route('procurement.index');
    } catch (\Exception $ex) {
      Session::flash('error_message', 'Somthing went wrong, please try again...');
      return redirect()->route('procurement.index');
    }
  }
}
