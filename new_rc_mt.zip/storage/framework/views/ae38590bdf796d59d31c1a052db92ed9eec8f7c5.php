
<?php $__env->startSection('page_specific_css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/front\css\plugin\jquery-ui.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="manageTable">
       
        <div class="alert alert-danger error_message d-none">
            
        </div>
       <div class="d-flex justify-content-between flex-wrap align-items-center">
            <div class="d-flex "> 
                <a class="me-3" href="<?php echo e(route('infrastructure.index')); ?>"><img src="<?php echo e(asset('public/front\themes\svg\arrow-left-circle.svg')); ?>" alt="">
                </a>
                <h3 >Edit Infrastructure Project Details</h3>
            </div>
        </div>



        <div class="table-responsive mt-3">
            <form class="infra_master" action="<?php echo e(route('infrastructure.update')); ?>" method="POST">
                <?php echo csrf_field(); ?>
            <table class="table table-bordered pt-2">
                <thead>
                    <tr>
                        <th>SN.NO</th>
                        <th>PROJECT ID / TITLE</th>
                        <th>COST AS PER PE (IN CR.)</th>
                        <th>DATE OF AA/ES</th>
                        <th>AGENCY</th>
                        <th>STATUS</th>
                        
                    </tr>
                </thead>
                
                <tbody id="multiple_infra_form_container">
                    
                        <tr class="row_0">
                            <td>1</td>
                            <td>
                                <input type="hidden" name="id" value ="<?php echo e($data->id); ?>">
                                <input type="text" name="project_title" class="form-control" placeholder="Project ID / Title" value="<?php echo e(old('project_title',$data->project_title)); ?>" autocomplete="off" >
                                <?php $__errorArgs = ['project_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                
                            </td>
                            <td>
                                <input type="number" step=any class="form-control" name="cost" placeholder="Cost" value="<?php echo e(old('cost',$data->cost)); ?>" autocomplete="off">
                                <?php $__errorArgs = ['cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                            <td>
                                <input type="text" class="form-control datepicker" name="date" value="<?php echo e(old('date',date('d-m-Y',strtotime($data->date)))); ?>" autocomplete="off" placeholder="Select a date">
                                <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                            <td>
                                <select class="form-control" name ="agency" autocomplete="off">
                                    <option disabled> Select Agency </option>
                                    <?php $__currentLoopData = $agencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a_key => $a_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($a_key); ?>" <?php echo e(old('agency',$data->agency_id) == $a_key ? 'selected' : ''); ?>><?php echo e($a_value); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['agency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                            <td>
                                <select class="form-control" name ="status" autocomplete="off">
                                    <option disabled> Select Status </option>
                                    
                                    <option value="1" <?php echo e(old('status',$data->status) == '1' ? 'selected' : ''); ?>><?php echo e(__('Active')); ?></option>
                                    <option value="0" <?php echo e(old('status',$data->status) == '0' ? 'selected' : ''); ?>><?php echo e(__('In-Active')); ?></option>
                                    
                                </select>
                                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                            
                        </tr>
                   
                    
                </tbody>
                <tr>
                    <td colspan="7"class="text-end">
                     <button type="submit" class="btn btn-warning px-md-4">Update</button>
 
                    </td>
                    </tr>
                
            
            </table>
        </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_specific_js'); ?>
<script src="<?php echo e(asset('public/front\js\plugin\jquery-ui.js')); ?>"></script>
<script>
     $(document).ready(function(){
        $( ".datepicker" ).datepicker({
            slideDown : true,
            dateFormat : "dd-mm-yy",
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rc_mt\resources\views/front/pages/masters/infrastructure/edit.blade.php ENDPATH**/ ?>