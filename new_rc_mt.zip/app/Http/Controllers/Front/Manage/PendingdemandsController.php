<?php

namespace App\Http\Controllers\Front\Manage;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
// use App\Models\Manage\Financemanages;
// use App\Models\Manage\Miscellaneousmanages;
// use App\Models\Manage\Miscinfraawardtender;
use App\Models\Manage\Pendingdemandsmanage;
use App\Models\Masters\Miscmaster;
use App\Models\Masters\Agency;
use Illuminate\Support\Facades\Session;

class PendingdemandsController extends Controller
{
    public function index($temp_id){
             
      try {        
        $decode_temp_id = decode5t($temp_id);
        $user_id = Session::get('user')->user_id;
        $data1 = Pendingdemandsmanage::with(['pendingdemandsmanage'])->where('created_by',$user_id)->where('template_id',$decode_temp_id)->get();

        return view('front.pages.manage.pendingdemands.index', ['data1' => $data1,'temp_id' => decode5t($temp_id)]);

      } catch (\Exception $ex) {
        
        $message = 'Somthing went wrong, Please try again...';
        return view('404_page', ['message' => $message, 'error_code' => 400]);
      }
    }

    // store function status of court cases  
    public function store(Request $request){

        //   dd($request->all());
      // misc_manage
      $validator = Validator::make($request->all(),[
        
        "pendingdemandsmanages.*.particulars"    => "required|unique:pendingdemandsmanage,particulars",
        "misc_manage.*.last_correspondence_regional"    => "required",

      ],[
        
        'pendingdemandsmanages.*.particulars.required' => 'Please enter particulars',
        'pendingdemandsmanages.*.particulars.unique' => 'Particulars already exist',
        'pendingdemandsmanages.*.last_correspondence_regional.required' => 'Please select Last Correspondence From Regional Office To Sai Ho',
      
      ]);

      if($validator->fails()) {

        // Session::flash('error_message', 'Duplicate entry');
        // return view ('front.pages.manage.pendingdemands.index');
        return response()->json(['success' => true, 'error_message' => 'Duplicate entry.']);
        // return response()->json(['success' => false, 'message' => $validator->errors()->first()]);

      }
      
      $updated_by = $created_by = $user_id = Session::get('user')->user_id; 

      try{
        
        foreach($request->pendingdemands as $key => $value) {
          $last_correspondence_regional = isset($value['last_correspondence_regional']) ? date('Y-m-d', strtotime($value['last_correspondence_regional'])) : null;
          
          if(array_key_exists("id",$value)){
  
            if($value['id'] != '' ){
              
              $Pendingdemandsmanage = Pendingdemandsmanage::findOrFail($value['id']);
              $Pendingdemandsmanage->particulars = $value['particulars'];
              $Pendingdemandsmanage->template_id = $value['template_id'];
              $Pendingdemandsmanage->last_correspondence_regional = $last_correspondence_regional;
              $Pendingdemandsmanage->concerned_division_personnel = $value['concerned_division_personnel'];
              $Pendingdemandsmanage->row_status = $value['row_status'];
              $Pendingdemandsmanage->remarks = $value['remarks'];
              $Pendingdemandsmanage->user_id = $user_id;
              // $Pendingdemandsmanage->created_for = $created_for;
              // $Miscellaneousmanages->created_by = $created_by;
              $Pendingdemandsmanage->updated_by = $updated_by;
              // $Miscellaneousmanages->deleted_by = $deleted_by;              
              $Pendingdemandsmanage->status = 1;
              $Pendingdemandsmanage->save(); 

            }
          }
            else{

              // dd('ABCD');
              $Pendingdemandsmanage = new Pendingdemandsmanage();
              $Pendingdemandsmanage->particulars = $value['particulars'];
              $Pendingdemandsmanage->template_id = $value['template_id'];
              $Pendingdemandsmanage->last_correspondence_regional = $last_correspondence_regional;
              $Pendingdemandsmanage->concerned_division_personnel = $value['concerned_division_personnel'];
              $Pendingdemandsmanage->row_status = $value['row_status'];
              $Pendingdemandsmanage->remarks = $value['remarks'];
              $Pendingdemandsmanage->user_id = $user_id;
              // $Pendingdemandsmanage->created_for = $created_for;
              $Pendingdemandsmanage->created_by = $created_by;
              // $Miscellaneousmanages->updated_by = $updated_by;
              // $Miscellaneousmanages->deleted_by = $deleted_by;              
              $Pendingdemandsmanage->status = 1;
              $Pendingdemandsmanage->save();
            }
        }
  
        Session::flash('message', 'Record Created.');
        return response()->json(['success' => true, 'message' => 'Data added successfully!']);
      } catch (\Exception $ex) {
        // $message = 'Somthing went wrong, Please try again...';
        // return view('404_page', ['message' => $message, 'error_code' => 400]);
        return response()->json(['success' => false, 'message' => 'Duplicate entry']);
      }
    }   

    // deleted function status of court cases
    public function pendingDeleteById($id){
      $user_id = Session::get('user')->user_id;
      try {
        $infra = Pendingdemandsmanage::findOrFail($id);
        if($infra->delete()){
          $infra->deleted_by = $user_id;
          $infra->save();
          return response()->json(['success' => true, 'message' => 'Records Deleted.']);
        }else{
          return response()->json(['success' => true, 'message' => 'Records Deleted.']);
        }
        
      } catch (\Exception $ex) {
        $message = 'Somthing went wrong, Please try again...';
        return view('404_page', ['message' => $message, 'error_code' => 400]);
      }
    }
}
