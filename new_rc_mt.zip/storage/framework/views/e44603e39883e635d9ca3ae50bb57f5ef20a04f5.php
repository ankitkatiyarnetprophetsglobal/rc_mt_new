
<?php $__env->startSection('page_specific_css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/front/themes/css/jquery.dataTables.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="manageTable">

    <?php if(Session::has('message')): ?>
        <div class="alert alert-success">
            <strong>Success!</strong> <?php echo e(Session::get('message')); ?>

        </div>
    <?php endif; ?>

    <?php if(Session::has('error_message')): ?>
        <div class="alert alert-danger">
            <strong>Danger!</strong> <?php echo e(Session::get('error_message')); ?>

        </div>
    <?php endif; ?>

    <h3 class="d-flex justify-content-between flex-wrap align-items-center">Miscellaneous Master
        <a class="btn btn-outline-success" href="<?php echo e(route('masters.miscmaster.create')); ?>">
            <i class="fa-solid fa-plus"></i> ADD
        </a>
    </h3>

    <div class="table-responsive mt-3">
        <table class="table table-bordered pt-2" id="masterfinance">
            <thead>
                <tr>
                    <th>SN.NO</th>
                    <th>Details of the OA/WP/CWP/CP/SLP</th>
                    <th>Name of the Court</th>
                    <th>Brief issue involved in the Court case</th>
                    <th>Name of the parties</th>
                    <th>Name of the Counsel</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key + 1); ?></td>
                        <td><?php echo e($value->detail_cwp_slp ?? ''); ?></td>
                        <td><?php echo e($value->court_name ?? ''); ?></td>
                        <td><?php echo e($value->court_case ?? ''); ?></td>
                        <td><?php echo e($value->parties_name ?? ''); ?></td>
                        <td><?php echo e($value->counsel_name ?? ''); ?></td>
                        <td>
                            <a href="<?php echo e(route('masters.miscmaster.edit', encode5t($value->id))); ?>" class="actionbtn"><i class="fa-regular fa-pen-to-square"></i></a>
                            <a href="<?php echo e(route('masters.miscmaster.delete', encode5t($value->id))); ?>" class="actionbtn"><i class="fa-solid fa-trash-can"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </tbody>
        </table>
    </div>
</div>

<!--close common-card-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_specific_js'); ?>

<script src="<?php echo e(asset('public/front/themes/js/jquery.dataTables.min.js')); ?>"></script>
    
    <script>
    
    $(document).ready(function() {
    
        $('#masterfinance').DataTable( {            
        });
    });
    
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rc_mt\resources\views/front/pages/masters/miscmaster/index.blade.php ENDPATH**/ ?>