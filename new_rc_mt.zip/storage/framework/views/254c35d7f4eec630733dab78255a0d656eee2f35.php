
<?php $__env->startSection('page_specific_css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/front/themes/css/jquery.dataTables.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="manageTable">
        <?php if(Session::has('message')): ?>
            <div class="alert alert-success">
                <strong>Success!</strong> <?php echo e(Session::get('message')); ?>

            </div>
        <?php endif; ?>
        <?php if(Session::has('error_message')): ?>
            <div class="alert alert-danger">
                <strong>Danger!</strong> <?php echo e(Session::get('error_message')); ?>

            </div>
        <?php endif; ?>
        <h3 class="d-flex justify-content-between flex-wrap align-items-center">Procurement Title / Details<a
                class="btn btn-outline-success" href="<?php echo e(route('procurement.create')); ?>"><i class="fa-solid fa-plus"></i>
                ADD</a></h3>
        <div class="table-responsive mt-3">
            <table class="table table-bordered pt-2" id="masterInfra">
                <thead>
                    <tr>
                        <th>SN.NO</th>
                        <th>Type</th>
                        <th>Title / Details</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($data->count()): ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($value->type ?? ''); ?></td>
                            <td><?php echo e($value->title ?? ''); ?></td>
                            <td>
                            <?php if($value->status): ?>
                            <div class="green_outline">Active</div>
                            <?php else: ?> 
                            <div class="red_outline">In-Active</div>
                            <?php endif; ?>
                            </td>
                            
                            <td>
                                
                                <a href="<?php echo e(route('procurement.edit', encode5t($value->id))); ?>" class="actionbtn"><i
                                        class="fa-regular fa-pen-to-square"></i></a>
                                <a href="<?php echo e(route('procurement.delete', encode5t($value->id))); ?>" class="actionbtn"><i
                                        class="fa-regular fa-trash-can"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?> 
                  <td colspan="5" class="text-center"><?php echo e(__('No Data Found')); ?></td>
                    <?php endif; ?>

                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_specific_js'); ?>
    <script src="<?php echo e(asset('public/front/themes/js/jquery.dataTables.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rc_mt\resources\views/front/pages/masters/procurement/index.blade.php ENDPATH**/ ?>