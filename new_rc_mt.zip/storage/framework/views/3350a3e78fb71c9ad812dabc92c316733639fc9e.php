
<?php $__env->startSection('page_specific_css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/front/themes/css/jquery.dataTables.min.css')); ?>">
    <script>
        var selected_title = [];
        var selected_title_2 = [];
        var selected_title_5 = [];
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="manageInfracture">

        <div class="manageTable mb-5">
            <h3 class="d-flex justify-content-between flex-wrap align-items-center">
                STATUS OF FUNDS FOR EQUIPMENT PROCUREMENT
                <!-- <button type="button" class="btn btn-outline-success" onClick={handleAddFields}>+ ADD</button> -->
            </h3>
            <form id="first_form">
                <?php echo csrf_field(); ?>
                <div class="table-responsive">
                    <table class="table table-bordered  text-center">
                        <thead>
                            <tr>
                                <th rowSpan="2">S. NO</th>
                                <th rowSpan="2" class="text-start">PARTCULARS</th>

                                <th colSpan="2">BUDGETHEAD</th>

                            </tr>
                            <tr>

                                <th>SPORTS EQUIPMENT</th>
                                <th>SPORTS SCIENCE EQUIPMENT</th>

                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>01</td>
                                <td class="text-start">
                                    Opening Balance
                                </td>
                                <td>
                                    <input type="hidden" name="template_id" value="<?php echo e($temp_id); ?>">
                                    <?php if(isset($data_1)): ?>
                                        <input type="hidden" name="id" value="<?php echo e($data_1->id ?? ''); ?>">
                                    <?php endif; ?>
                                    <input type="number" step=any name="se_opening_balance"
                                        value="<?php echo e($data_1->se_opening_balance ?? ''); ?>"
                                        class="form-control allownumeric se_opening_balance" placeholder="" autocomplete="off">
                                    <span class="text-danger error_se_opening_balance"></span>
                                </td>
                                <td>
                                    <input type="number" step=any name="sse_opening_balance"
                                        value="<?php echo e($data_1->sse_opening_balance ?? ''); ?>"
                                        class="form-control allownumeric sse_opening_balance" placeholder="" autocomplete="off">
                                    <span class="text-danger error_sse_opening_balance"></span>
                                </td>

                            </tr>

                            <tr>
                                <td>02</td>
                                <td class="text-start">
                                    Administrative approval (including budget) of HO received (Rs) – Sports Science
                                </td>
                                <td>
                                    <input type="number" step=any name="se_administrative_approval_budget"
                                        value="<?php echo e($data_1->se_administrative_approval_budget ?? ''); ?>"
                                        class="form-control se_administrative_approval_budget" placeholder="" autocomplete="off">
                                    <span class="text-danger error_se_administrative_approval_budget"></span>
                                </td>
                                <td>
                                    <input type="number" step=any name="sse_administrative_approval_budget"
                                        value="<?php echo e($data_1->sse_administrative_approval_budget ?? ''); ?>"
                                        class="form-control sse_administrative_approval_budget" placeholder="" autocomplete="off">
                                    <span class="text-danger error_sse_administrative_approval_budget"></span>
                                </td>

                            </tr>

                            <tr>
                                <td>03</td>
                                <td class="text-start">
                                    Funds transferred during Current FY (Rs) - Sports Science
                                </td>
                                <td>
                                    <input type="number" step=any name="se_fund_transfer"
                                        value="<?php echo e($data_1->se_fund_transfer ?? ''); ?>" class="form-control se_fund_transfer"
                                        placeholder="">
                                    <span class="text-danger error_se_fund_transfer"></span>
                                </td>
                                <td>
                                    <input type="number" step=any name="sse_fund_transfer"
                                        value="<?php echo e($data_1->sse_fund_transfer ?? ''); ?>"
                                        class="form-control sse_fund_transfer" placeholder="" autocomplete="off">
                                    <span class="text-danger error_sse_fund_transfer"></span>
                                </td>

                            </tr>

                            <tr>
                                <td>04</td>
                                <td class="text-start">
                                    Total fund available for Sports Science (1+3)
                                </td>
                                <td>
                                    <input type="number" step=any name="se_total_fund_available"
                                        value="<?php echo e($data_1->se_total_fund_available ?? ''); ?>"
                                        class="form-control se_total_fund_available" placeholder="" readonly autocomplete="off">
                                    <span class="text-danger error_se_total_fund_available"></span>
                                </td>
                                <td>
                                    <input type="number" step=any name="sse_total_fund_available"
                                        value="<?php echo e($data_1->sse_total_fund_available ?? ''); ?>"
                                        class="form-control sse_total_fund_available" placeholder="" readonly autocomplete="off">
                                    <span class="text-danger error_sse_total_fund_available"></span>
                                </td>

                            </tr>
                            <tr>
                                <td>05</td>
                                <td class="text-start">
                                    Funds requirement (if any) (4-2)
                                </td>
                                <td>
                                    <input type="number" step=any name="se_fund_requirement"
                                        value="<?php echo e($data_1->se_fund_requirement ?? ''); ?>"
                                        class="form-control se_fund_requirement" placeholder="" readonly autocomplete="off">
                                    <span class="text-danger error_se_fund_requirement"></span>
                                </td>
                                <td>
                                    <input type="number" step=any name="sse_fund_requirement"
                                        value="<?php echo e($data_1->sse_fund_requirement ?? ''); ?>"
                                        class="form-control sse_fund_requirement" placeholder="" readonly autocomplete="off">
                                    <span class="text-danger error_sse_fund_requirement"></span>
                                </td>

                            </tr>
                            <tr>
                                <td colspan="12" class="text-end">
                                    <button type="submit" class="btn btn-warning px-md-4">Save</button>
                                </td>
                            </tr>


                        </tbody>
                    </table>
                </div>
            </form>
        </div>
        <div class="manageTable my-5">
            <h3 class="d-flex justify-content-between flex-wrap align-items-center">
                STATUS OF BUDGET FOR EQUIPMENT PROCUREMENT AT THE END OF THE MONTH

            </h3>
            <form id="second_form">
                <?php echo csrf_field(); ?>
                <div class="table-responsive">
                    <table class="table table-bordered  text-center">
                        <thead>
                            <tr>
                                <th rowSpan="2">S. NO</th>
                                <th rowSpan="2" class="text-start">DETAILS</th>
                                <th colspan="3">COST AS PER PE (IN CR.)</th>
                                <th rowSpan="2">AMOUNT RECEIVED FROM HQ</th>
                                <th rowSpan="2">AMOUNT INCURRED ON PROCUREMENT OF EQUIPMENT (IN RS)</th>
                                <th rowspan="2">PROCUREMENT UNDER PROCESS (AMOUNT IN RS)</th>
                                <th rowSpan="2">UTILISATION PLAN OF EMAINING FUNDS (IN RS)</th>
                                <th rowSpan="2">FUNDS REQUIREMENT/ EXCESS APART FROM APPROVED BUDGET IN COLUMN III(IN
                                    RS)
                                </th>
                                <th rowSpan="2">REMARKS</th>
                            </tr>
                            <tr>
                                <th>NCOE</th>
                                <th>STC</th>
                                <th>TOTAL</th>

                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>01</td>
                                <td class="text-start">
                                    Sports Equipment
                                </td>
                                <td>
                                    <input type="hidden" name="template_id" value="<?php echo e($temp_id); ?>">
                                    <?php if(isset($data_2)): ?>
                                        <input type="hidden" name="id" value="<?php echo e($data_2->id); ?>">
                                    <?php endif; ?>
                                    <input type="number" step=any class="form-control se_ncoe_cost" name="se_ncoe_cost"
                                        value="<?php echo e($data_2->se_ncoe_cost ?? ''); ?>" placeholder="" autocomplete="off">
                                    <span class="text-danger error_se_ncoe_cost"></span>
                                </td>
                                <td>
                                    <input type="number" step=any class="form-control se_stc_cost" name="se_stc_cost"
                                        value="<?php echo e($data_2->se_stc_cost ?? ''); ?>" placeholder="" autocomplete="off">
                                    <span class="text-danger error_se_stc_cost"></span>
                                </td>
                                <td>
                                    <input type="number" step=any class="form-control se_total_cost"
                                        name="se_total_cost" value="<?php echo e($data_2->se_total_cost ?? ''); ?>" placeholder=""
                                        readonly autocomplete="off">
                                    <span class="text-danger error_se_total_cost"></span>
                                </td>
                                <td>
                                    <input type="number" step=any class="form-control se_amt_recive_from_hq"
                                        name="se_amt_recive_from_hq" value="<?php echo e($data_2->se_amt_recive_from_hq ?? ''); ?>"
                                        placeholder="" autocomplete="off">
                                    <span class="text-danger error_se_amt_recive_from_hq"></span>
                                </td>
                                <td>
                                    <input type="number" step=any
                                        class="form-control se_amt_incurred_on_procurement_of_equipment"
                                        name="se_amt_incurred_on_procurement_of_equipment"
                                        value="<?php echo e($data_2->se_amt_incurred_on_procurement_of_equipment ?? ''); ?>"
                                        placeholder="" autocomplete="off">
                                    <span class="text-danger error_se_amt_incurred_on_procurement_of_equipment"></span>
                                </td>
                                <td>
                                    <input type="number" step=any class="form-control se_procurement_under_process_amt"
                                        name="se_procurement_under_process_amt"
                                        value="<?php echo e($data_2->se_procurement_under_process_amt ?? ''); ?>" placeholder="" autocomplete="off">
                                    <span class="text-danger error_se_procurement_under_process_amt"></span>
                                </td>
                                <td>
                                    <input type="number" step=any
                                        class="form-control se_utilisation_plan_of_remaining_funds"
                                        name="se_utilisation_plan_of_remaining_funds"
                                        value="<?php echo e($data_2->se_utilisation_plan_of_remaining_funds ?? ''); ?>"
                                        placeholder="" autocomplete="off">
                                    <span class="text-danger error_se_utilisation_plan_of_remaining_funds"></span>
                                </td>
                                <td>
                                    <input type="number" step=any
                                        class="form-control se_funds_requirement_from_approved_budget"
                                        name="se_funds_requirement_from_approved_budget"
                                        value="<?php echo e($data_2->se_funds_requirement_from_approved_budget ?? ''); ?>"
                                        placeholder="" autocomplete="off">
                                    <span class="text-danger error_se_funds_requirement_from_approved_budget"></span>
                                </td>

                                <td>
                                    <input type="text" class="form-control se_remarks" name="se_remarks"
                                        value="<?php echo e($data_2->se_remarks ?? ''); ?>" placeholder="" autocomplete="off">
                                    <span class="text-danger error_se_remarks"></span>
                                </td>
                            </tr>
                            <tr>
                                <td>02</td>
                                <td class="text-start">
                                    Sports Science Equipment
                                </td>
                                <td>
                                    <input type="number" step=any class="form-control sse_ncoe_cost"
                                        name="sse_ncoe_cost" value="<?php echo e($data_2->sse_ncoe_cost ?? ''); ?>" placeholder="" autocomplete="off">
                                    <span class="text-danger error_sse_ncoe_cost"></span>
                                </td>
                                <td>
                                    <input type="number" step=any class="form-control sse_stc_cost" name="sse_stc_cost"
                                        value="<?php echo e($data_2->sse_stc_cost ?? ''); ?>" placeholder="" autocomplete="off">
                                    <span class="text-danger error_sse_stc_cost"></span>
                                </td>
                                <td>
                                    <input type="number" step=any class="form-control sse_total_cost"
                                        name="sse_total_cost" value="<?php echo e($data_2->sse_total_cost ?? ''); ?>" placeholder=""
                                        readonly autocomplete="off">
                                    <span class="text-danger error_sse_total_cost"></span>
                                </td>
                                <td>
                                    <input type="number" step=any class="form-control sse_amt_recive_from_hq"
                                        name="sse_amt_recive_from_hq" value="<?php echo e($data_2->sse_amt_recive_from_hq ?? ''); ?>"
                                        placeholder="" autocomplete="off">
                                    <span class="text-danger error_sse_amt_recive_from_hq"></span>
                                </td>
                                <td>
                                    <input type="number" step=any
                                        class="form-control sse_amt_incurred_on_procurement_of_equipment"
                                        name="sse_amt_incurred_on_procurement_of_equipment"
                                        value="<?php echo e($data_2->sse_amt_incurred_on_procurement_of_equipment ?? ''); ?>"
                                        placeholder="" autocomplete="off">
                                    <span class="text-danger error_sse_amt_incurred_on_procurement_of_equipment"></span>
                                </td>
                                <td>
                                    <input type="number" step=any class="form-control sse_procurement_under_process_amt"
                                        name="sse_procurement_under_process_amt"
                                        value="<?php echo e($data_2->sse_procurement_under_process_amt ?? ''); ?>" placeholder="" autocomplete="off">
                                    <span class="text-danger error_sse_procurement_under_process_amt"></span>
                                </td>
                                <td>
                                    <input type="number" step=any
                                        class="form-control sse_utilisation_plan_of_remaining_funds"
                                        name="sse_utilisation_plan_of_remaining_funds"
                                        value="<?php echo e($data_2->sse_utilisation_plan_of_remaining_funds ?? ''); ?>"
                                        placeholder="" autocomplete="off">
                                    <span class="text-danger error_sse_utilisation_plan_of_remaining_funds"></span>
                                </td>
                                <td>
                                    <input type="number" step=any
                                        class="form-control sse_funds_requirement_from_approved_budget"
                                        name="sse_funds_requirement_from_approved_budget"
                                        value="<?php echo e($data_2->sse_funds_requirement_from_approved_budget ?? ''); ?>"
                                        placeholder="" autocomplete="off">
                                    <span class="text-danger error_sse_funds_requirement_from_approved_budget"></span>
                                </td>

                                <td>
                                    <input type="text" class="form-control sse_remarks" name="sse_remarks"
                                        value="<?php echo e($data_2->sse_remarks ?? ''); ?>" placeholder="" autocomplete="off">
                                    <span class="text-danger error_sse_funds_requirement_from_approved_budget"></span>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="12" class="text-end">
                                    <button type="submit" class="btn btn-warning px-md-4">Save</button>
                                </td>
                            </tr>

                        </tbody>
                    </table>
                </div>
            </form>
        </div>
        <div class="manageTable my-5">
            <h3 class="d-flex justify-content-between flex-wrap align-items-center">
                EQUIPMENT PROCUREMENT STATUS
                <button type="button" class="btn btn-outline-success third_form_add_btn">+ ADD</button>
            </h3>
            <form id="third_form">
                <div class="table-responsive">
                    <table class="table table-bordered  text-center">
                        <thead>
                            <tr>
                                <th rowSpan="2">SN.NO</th>
                                <th rowSpan="2" class="text-start">PROCUREMENT DETAILS*</th>
                                <th rowspan="2" class="text-start">SPECS. FINALIZED (YES/NO)</th>
                                <th rowSpan="2" class="text-start">TENDER TYPE (OPEN/ LIMITED/ PAC)</th>
                                <th rowSpan="2" class="text-start">ESTIMATED VALUE IN LAKHS</th>
                                <th colspan="6">DATE OF</th>
                                <th rowSpan="2" class="text-start">TENDER VALUE IN LAKHS</th>
                                <th rowSpan="2">REMARKS</th>
                                <th rowSpan="2">Remove</th>

                            </tr>
                            <tr>
                                <th>SPECS FINALISATION</th>
                                <th>FLOATING TENDER</th>
                                <th>OPENING TENDER</th>
                                <th>TECH. EVAL.</th>
                                <th>FIN. EVAL.</th>
                                <th>ORDER PLACEMENT</th>

                            </tr>
                        </thead>
                        <tbody class="form_third_container">
                            <?php if($data_3->count()): ?>
                                <?php $__currentLoopData = $data_3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <script>
                                        selected_title.push("<?php echo e($value->title_id); ?>");
                                    </script>
                                    <tr class="row_0">
                                        <td><?php echo e($key + 1); ?></td>

                                        <td class="text-start">

                                            <input type="hidden" name="pro[<?php echo e($key); ?>][template_id]"
                                                value="<?php echo e($value->template_id); ?>" autocomplete="off">
                                            <input type="hidden" name="pro[<?php echo e($key); ?>][id]"
                                                value="<?php echo e($value->id); ?>" autocomplete="off">

                                            <select class="form-control title_id title_id_<?php echo e($key); ?>"
                                                data-id="<?php echo e($key); ?>" name="pro[<?php echo e($key); ?>][title_id]">
                                                <option selected disabled>Select</option>
                                                <?php $__currentLoopData = $title_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($k); ?>"
                                                        <?php if($k == $value->title_id): ?> selected <?php endif; ?>>
                                                        <?php echo e($val); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <span class="text-danger error_title_id_<?php echo e($key); ?>"></span>
                                        </td>
                                        <td class="text-start">
                                            <select class="form-control specs_finalized_<?php echo e($key); ?>"
                                                name="pro[<?php echo e($key); ?>][specs_finalized]">
                                                <option selected disabled>Select</option>
                                                <option value="yes" <?php if($value->specs_finalized == 'yes'): ?> selected <?php endif; ?>>
                                                    <?php echo e(__('Yes')); ?></option>
                                                <option value="no" <?php if($value->specs_finalized == 'no'): ?> selected <?php endif; ?>>
                                                    <?php echo e(__('No')); ?></option>

                                            </select>
                                            <span class="text-danger error_specs_finalized_0"></span>
                                        </td>
                                        <td class="text-start">
                                            <select class="form-control tender_type_<?php echo e($key); ?>"
                                                name="pro[<?php echo e($key); ?>][tender_type]">
                                                <option selected disabled>Select</option>
                                                <option value="open" <?php if($value->tender_type == 'open'): ?> selected <?php endif; ?>>
                                                    <?php echo e(__('Open')); ?></option>
                                                <option value="limited" <?php if($value->tender_type == 'limited'): ?> selected <?php endif; ?>>
                                                    <?php echo e(__('Limited')); ?></option>
                                                <option value="pac" <?php if($value->tender_type == 'pac'): ?> selected <?php endif; ?>>
                                                    <?php echo e(__('PAC')); ?></option>

                                            </select>
                                            <span class="text-danger error_tender_type_<?php echo e($key); ?>"></span>
                                        </td>


                                        <td>
                                            <input type="number" step=any
                                                name="pro[<?php echo e($key); ?>][estimated_value]"
                                                class="form-control estimated_value_<?php echo e($key); ?>"
                                                value="<?php echo e($value->estimated_value ?? ''); ?>" placeholder=""
                                                autocomplete="off">
                                            <span class="text-danger error_estimated_value_<?php echo e($key); ?>"></span>
                                        </td>
                                        <td>
                                            <input type="text"
                                                name="pro[<?php echo e($key); ?>][specs_finalization_date]"
                                                class="form-control specs_finalization_date specs_finalization_date_<?php echo e($key); ?>"
                                                data-id="<?php echo e($key); ?>" placeholder="dd-mm-yyyy"
                                                value="<?php echo e(isset($value->specs_finalization_date) ? date('d-m-Y', strtotime($value->specs_finalization_date)) : ''); ?>"
                                                autocomplete="off">
                                            <span
                                                class="text-danger error_specs_finalization_date_<?php echo e($key); ?>"></span>
                                        </td>
                                        <td>
                                            <input type="text" name="pro[<?php echo e($key); ?>][floating_tender_date]"
                                                value="<?php echo e(isset($value->floating_tender_date) ? date('d-m-Y', strtotime($value->floating_tender_date)) : ''); ?>"
                                                class="form-control floating_tender_date floating_tender_date_<?php echo e($key); ?>"
                                                data-id="<?php echo e($key); ?>" placeholder="dd-mm-yyyy" readonly
                                                autocomplete="off">
                                            <span
                                                class="text-danger error_floating_tender_date_<?php echo e($key); ?>"></span>
                                        </td>
                                        <td>
                                            <input type="text" name="pro[<?php echo e($key); ?>][opening_tender_date]"
                                                value="<?php echo e(isset($value->opening_tender_date) ? date('d-m-Y', strtotime($value->opening_tender_date)) : ''); ?>"
                                                class="form-control opening_tender_date opening_tender_date_<?php echo e($key); ?>"
                                                data-id="<?php echo e($key); ?>" placeholder="dd-mm-yyyy" readonly
                                                autocomplete="off">
                                            <span
                                                class="text-danger error_opening_tender_date_<?php echo e($key); ?>"></span>
                                        </td>
                                        <td>
                                            <input type="text" name="pro[<?php echo e($key); ?>][tech_eval_date]"
                                                value="<?php echo e(isset($value->tech_eval_date) ? date('d-m-Y', strtotime($value->tech_eval_date)) : ''); ?>"
                                                class="form-control tech_eval_date_<?php echo e($key); ?> tech_eval_date"
                                                data-id="<?php echo e($key); ?>" placeholder="dd-mm-yyyy" readonly
                                                autocomplete="off">
                                            <span class="text-danger error_tech_eval_date_<?php echo e($key); ?>"></span>
                                        </td>
                                        <td>
                                            <input type="text" name="pro[<?php echo e($key); ?>][final_eval_date]"
                                                value="<?php echo e(isset($value->final_eval_date) ? date('d-m-Y', strtotime($value->final_eval_date)) : ''); ?>"
                                                class="form-control final_eval_date_<?php echo e($key); ?> final_eval_date"
                                                data-id="<?php echo e($key); ?>" placeholder="dd-mm-yyyy" readonly
                                                autocomplete="off">
                                            <span class="text-danger error_final_eval_date_<?php echo e($key); ?>"></span>
                                        </td>
                                        <td>
                                            <input type="text" name="pro[<?php echo e($key); ?>][order_placement_date]"
                                                value="<?php echo e(isset($value->order_placement_date) ? date('d-m-Y', strtotime($value->order_placement_date)) : ''); ?>"
                                                class="form-control order_placement_date_<?php echo e($key); ?> order_placement_date"
                                                data-id="<?php echo e($key); ?>" placeholder="dd-mm-yyyy" readonly
                                                autocomplete="off">
                                            <span
                                                class="text-danger error_order_placement_date_<?php echo e($key); ?>"></span>
                                        </td>
                                        <td>
                                            <input type="nubmer" step=any name="pro[<?php echo e($key); ?>][tender_value]"
                                                value="<?php echo e($value->tender_value ?? ''); ?>"
                                                class="form-control tender_value_<?php echo e($key); ?>"
                                                data-id="<?php echo e($key); ?>" placeholder="" autocomplete="off">
                                            <span class="text-danger error_tender_value_<?php echo e($key); ?>"></span>
                                        </td>

                                        <td>
                                            <input type="text" name="pro[<?php echo e($key); ?>][remarks]"
                                                value="<?php echo e($value->remarks ?? ''); ?>"
                                                class="form-control remarks_<?php echo e($key); ?>"
                                                data-id="<?php echo e($key); ?>" placeholder="" autocomplete="off">
                                            <span class="text-danger error_remarks_<?php echo e($key); ?>"></span>

                                        </td>
                                        <td>
                                            <a href="javascript:void(0)" class="actionbtn remove_btn"
                                                data-id="<?php echo e($key); ?>" data-db_id="<?php echo e($value->id); ?>"><i
                                                    class="fa-solid fa-trash-can"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr class="row_0">
                                    <td>1</td>

                                    <td class="text-start">
                                        <input type="hidden" name="pro[0][template_id]" value="<?php echo e($temp_id); ?>"
                                            autocomplete="off">
                                        <select class="form-control title_id title_id_0" data-id="0"
                                            name="pro[0][title_id]">
                                            <option selected disabled>Select</option>
                                            <?php $__currentLoopData = $title_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($k); ?>"><?php echo e($val); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <span class="text-danger error_title_id_0"></span>
                                    </td>
                                    <td class="text-start">
                                        <select class="form-control specs_finalized_0" name="pro[0][specs_finalized]">
                                            <option selected disabled>Select</option>
                                            <option value="yes"><?php echo e(__('Yes')); ?></option>
                                            <option value="no"><?php echo e(__('No')); ?></option>

                                        </select>
                                        <span class="text-danger error_specs_finalized_0"></span>
                                    </td>
                                    <td class="text-start">
                                        <select class="form-control tender_type_0" name="pro[0][tender_type]">
                                            <option selected disabled>Select</option>
                                            <option value="open"><?php echo e(__('Open')); ?></option>
                                            <option value="limited"><?php echo e(__('Limited')); ?></option>
                                            <option value="pac"><?php echo e(__('PAC')); ?></option>

                                        </select>
                                        <span class="text-danger error_tender_type_0"></span>
                                    </td>


                                    <td>
                                        <input type="number" step=any name="pro[0][estimated_value]"
                                            class="form-control estimated_value_0" placeholder="" autocomplete="off">
                                        <span class="text-danger error_estimated_value_0"></span>
                                    </td>
                                    <td>
                                        <input type="text" name="pro[0][specs_finalization_date]"
                                            class="form-control specs_finalization_date specs_finalization_date_0"
                                            data-id="0" placeholder="dd-mm-yyyy" autocomplete="off">
                                        <span class="text-danger error_specs_finalization_date_0"></span>
                                    </td>
                                    <td>
                                        <input type="text" name="pro[0][floating_tender_date]"
                                            class="form-control floating_tender_date floating_tender_date_0"
                                            data-id="0" placeholder="dd-mm-yyyy" readonly autocomplete="off">
                                        <span class="text-danger error_floating_tender_date_0"></span>
                                    </td>
                                    <td>
                                        <input type="text" name="pro[0][opening_tender_date]"
                                            class="form-control opening_tender_date opening_tender_date_0" data-id="0"
                                            placeholder="dd-mm-yyyy" readonly autocomplete="off">
                                        <span class="text-danger error_opening_tender_date_0"></span>
                                    </td>
                                    <td>
                                        <input type="text" name="pro[0][tech_eval_date]"
                                            class="form-control tech_eval_date_0 tech_eval_date" data-id="0"
                                            placeholder="dd-mm-yyyy" readonly autocomplete="off">
                                        <span class="text-danger error_tech_eval_date_0"></span>
                                    </td>
                                    <td>
                                        <input type="text" name="pro[0][final_eval_date]"
                                            class="form-control final_eval_date_0 final_eval_date" data-id="0"
                                            placeholder="dd-mm-yyyy" readonly autocomplete="off">
                                        <span class="text-danger error_final_eval_date_0"></span>
                                    </td>
                                    <td>
                                        <input type="text" name="pro[0][order_placement_date]"
                                            class="form-control order_placement_date_0 order_placement_date"
                                            data-id="0" placeholder="dd-mm-yyyy" readonly autocomplete="off">
                                        <span class="text-danger error_order_placement_date_0"></span>
                                    </td>
                                    <td>
                                        <input type="nubmer" step=any name="pro[0][tender_value]"
                                            class="form-control tender_value_0" data-id="0" placeholder="">
                                        <span class="text-danger error_tender_value_0" autocomplete="off"></span>
                                    </td>

                                    <td>
                                        <input type="text" name="pro[0][remarks]" class="form-control remarks_0"
                                            data-id="0" placeholder="" autocomplete="off">
                                        <span class="text-danger error_remarks_0"></span>

                                    </td>
                                    <td>
                                        <a href="javascript:void(0)" class="actionbtn remove_btn" data-id="0"><i
                                                class="fa-solid fa-trash-can"></i></a>
                                    </td>
                                </tr>
                            <?php endif; ?>



                        </tbody>
                        <tr>
                            <td colspan="14" class="text-end">
                                <button type="submit" class="btn btn-warning px-md-4">Save</button>
                            </td>
                        </tr>
                    </table>
                </div>
            </form>
        </div>
        <div class="manageTable my-5">
            <h3 class="d-flex justify-content-between flex-wrap align-items-center">
                STATUS AFTER WORK ORDER PLACED FOR EQUIPMENT
                <button type="button" class="btn btn-outline-success fourth_form_add_btn">+ ADD</button>
            </h3>
            <form id="fourth_form">
                <div class="table-responsive">
                    <table class="table table-bordered  text-center">
                        <thead>
                            <tr>
                                <th rowSpan="2">SN.NO</th>
                                <th rowSpan="2" class="text-start">DESCRIPTION</th>
                                <th rowspan="2" class="text-start">BUDGET HEAD</th>
                                <th rowSpan="2" class="text-start">CONTRACT VALUE</th>

                                <th colspan="7">DATE OF</th>
                                <th rowSpan="2">REMARKS</th>
                                <th rowSpan="2">REMOVE</th>

                            </tr>
                            <tr>
                                <th>ISSUE OF ORDER</th>
                                <th>DELIVERY**</th>
                                <th>INSTALLATION (IF APPLICABLE)</th>
                                <th>SATISFACTORY CERTIFICATE RECEIPT</th>
                                <th>INVOICE RECEIPT</th>
                                <th>APPROVAL OF PAYMENT</th>
                                <th>PAYMENT RELEASE</th>


                            </tr>
                        </thead>
                        <tbody class="form_fourth_container">
                            <?php if($data_4->count()): ?>
                                <?php $__currentLoopData = $data_4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <script>
                                        selected_title_2.push("<?php echo e($value->title_id); ?>");
                                    </script>
                                    <tr class="row_2_<?php echo e($key); ?>">
                                        <td><?php echo e($key + 1); ?></td>
                                        <td class="text-start">
                                            <input type="hidden" name="pro[<?php echo e($key); ?>][template_id]"
                                                value="<?php echo e($value->template_id); ?>">
                                            <input type="hidden" name="pro[<?php echo e($key); ?>][id]"
                                                value="<?php echo e($value->id); ?>">
                                            <select class="form-control title_id_two title_id_two_<?php echo e($key); ?>"
                                                data-id="<?php echo e($key); ?>"
                                                name="pro[<?php echo e($key); ?>][title_id_two]">
                                                <option selected disabled>Select</option>
                                                <?php $__currentLoopData = $title_list_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($k); ?>"
                                                        <?php if($k == $value->title_id): ?> selected <?php endif; ?>>
                                                        <?php echo e($val); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <span class="text-danger error_title_id_two_<?php echo e($key); ?>"></span>
                                        </td>


                                        <td>
                                            <input type="number" step=any name="pro[<?php echo e($key); ?>][budget_head]"
                                                value="<?php echo e($value->budget_head ?? ''); ?>"
                                                class="form-control budget_head budget_head_<?php echo e($key); ?>"
                                                placeholder="" autocomplete="off">
                                            <span class="text-danger error_budget_head_<?php echo e($key); ?>"></span>
                                        </td>
                                        <td>
                                            <input type="number" step=any
                                                name="pro[<?php echo e($key); ?>][contract_amount]"
                                                value="<?php echo e($value->contract_amount ?? ''); ?>"
                                                class="form-control contract_amount contract_amount_<?php echo e($key); ?>"
                                                placeholder="" autocomplete="off">
                                            <span class="text-danger error_contract_amount_<?php echo e($key); ?>"></span>
                                        </td>
                                        <td>
                                            <input type="text" name="pro[<?php echo e($key); ?>][issue_of_order_date]"
                                                data-id="<?php echo e($key); ?>"
                                                value="<?php echo e(isset($value->issue_of_order_date) ? date('d-m-Y', strtotime($value->issue_of_order_date)) : ''); ?>"
                                                class="form-control issue_of_order_date issue_of_order_date_<?php echo e($key); ?>"
                                                placeholder="" autocomplete="off">
                                            <span
                                                class="text-danger error_issue_of_order_date_<?php echo e($key); ?>"></span>
                                        </td>
                                        <td>
                                            <input type="text" name="pro[<?php echo e($key); ?>][delivery_date]"
                                                data-id="<?php echo e($key); ?>"
                                                value="<?php echo e(isset($value->delivery_date) ? date('d-m-Y', strtotime($value->delivery_date)) : ''); ?>"
                                                class="form-control delivery_date delivery_date_<?php echo e($key); ?>"
                                                placeholder="" autocomplete="off">
                                            <span class="text-danger error_delivery_date_<?php echo e($key); ?>"></span>
                                        </td>
                                        <td>
                                            <input type="text" name="pro[<?php echo e($key); ?>][installation_date]"
                                                data-id="<?php echo e($key); ?>"
                                                value="<?php echo e(isset($value->installation_date) ? date('d-m-Y', strtotime($value->installation_date)) : ''); ?>"
                                                class="form-control installation_date installation_date_<?php echo e($key); ?>"
                                                placeholder="" autocomplete="off">
                                            <span class="text-danger error_installation_date_0"></span>
                                        </td>
                                        <td>
                                            <input type="text"
                                                name="pro[<?php echo e($key); ?>][satisfactory_certificate_receipt_date]"
                                                data-id="<?php echo e($key); ?>"
                                                value="<?php echo e(isset($value->satisfactory_certificate_receipt_date) ? date('d-m-Y', strtotime($value->satisfactory_certificate_receipt_date)) : ''); ?>"
                                                class="form-control satisfactory_certificate_receipt_date satisfactory_certificate_receipt_date_<?php echo e($key); ?>"
                                                placeholder="" autocomplete="off">
                                            <span
                                                class="text-danger error_satisfactory_certificate_receipt_date_<?php echo e($key); ?>"></span>
                                        </td>
                                        <td>
                                            <input type="text" name="pro[<?php echo e($key); ?>][invoice_receipt_date]"
                                                data-id="<?php echo e($key); ?>"
                                                value="<?php echo e(isset($value->invoice_receipt_date) ? date('d-m-Y', strtotime($value->invoice_receipt_date)) : ''); ?>"
                                                class="form-control invoice_receipt_date invoice_receipt_date_<?php echo e($key); ?>"
                                                placeholder="" autocomplete="off">
                                            <span
                                                class="text-danger error_invoice_receipt_date_<?php echo e($key); ?>"></span>
                                        </td>
                                        <td>
                                            <input type="text"
                                                name="pro[<?php echo e($key); ?>][approval_of_payment_date]"
                                                data-id="<?php echo e($key); ?>"
                                                value="<?php echo e(isset($value->approval_of_payment_date) ? date('d-m-Y', strtotime($value->approval_of_payment_date)) : ''); ?>"
                                                class="form-control approval_of_payment_date approval_of_payment_date_<?php echo e($key); ?>"
                                                placeholder="" autocomplete="off">
                                            <span
                                                class="text-danger error_approval_of_payment_date_<?php echo e($key); ?>"></span>
                                        </td>

                                        <td>
                                            <input type="text" name="pro[<?php echo e($key); ?>][payment_release_date]"
                                                data-id="<?php echo e($key); ?>"
                                                value="<?php echo e(isset($value->payment_release_date) ? date('d-m-Y', strtotime($value->payment_release_date)) : ''); ?>"
                                                class="form-control payment_release_date payment_release_date_<?php echo e($key); ?>"
                                                placeholder="" autocomplete="off">
                                            <span
                                                class="text-danger error_payment_release_date_<?php echo e($key); ?>"></span>

                                        </td>
                                        <td>
                                            <input type="text" name="pro[<?php echo e($key); ?>][remarks_2]"
                                                data-id="<?php echo e($key); ?>" value="<?php echo e($value->remarks_2 ?? ''); ?>"
                                                class="form-control remarks_2 remarks_2_<?php echo e($key); ?>"
                                                placeholder="" autocomplete="off">
                                            <span class="text-danger error_remarks_2_<?php echo e($key); ?>"></span>

                                        </td>
                                        <td>
                                            <a href="javascript:void(0)" class="actionbtn remove_btn_fourth"
                                                data-id="<?php echo e($key); ?>" data-db_id="<?php echo e($value->id); ?>"><i
                                                    class="fa-solid fa-trash-can"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr class="row_2_0">
                                    <td>01</td>
                                    <td class="text-start">
                                        <input type="hidden" name="pro[0][template_id]" value="<?php echo e($temp_id); ?>">
                                        <select class="form-control title_id_two title_id_two_0" data-id="0"
                                            name="pro[0][title_id_two]">
                                            <option selected disabled>Select</option>
                                            <?php $__currentLoopData = $title_list_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($k); ?>"><?php echo e($val); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <span class="text-danger error_title_id_two_0"></span>
                                    </td>


                                    <td>
                                        <input type="number" step=any name="pro[0][budget_head]"
                                            class="form-control budget_head budget_head_0" placeholder=""
                                            autocomplete="off">
                                        <span class="text-danger error_budget_head_0"></span>
                                    </td>
                                    <td>
                                        <input type="number" step=any name="pro[0][contract_amount]"
                                            class="form-control contract_amount contract_amount_0" placeholder=""
                                            autocomplete="off">
                                        <span class="text-danger error_contract_amount_0"></span>
                                    </td>
                                    <td>
                                        <input type="text" name="pro[0][issue_of_order_date]" data-id="0"
                                            class="form-control issue_of_order_date issue_of_order_date_0" placeholder=""
                                            autocomplete="off">
                                        <span class="text-danger error_issue_of_order_date_0"></span>
                                    </td>
                                    <td>
                                        <input type="text" name="pro[0][delivery_date]" data-id="0"
                                            class="form-control delivery_date delivery_date_0" placeholder=""
                                            autocomplete="off" readonly>
                                        <span class="text-danger error_delivery_date_0"></span>
                                    </td>
                                    <td>
                                        <input type="text" name="pro[0][installation_date]" data-id="0"
                                            class="form-control installation_date installation_date_0" placeholder=""
                                            autocomplete="off" readonly>
                                        <span class="text-danger error_installation_date_0"></span>
                                    </td>
                                    <td>
                                        <input type="text" name="pro[0][satisfactory_certificate_receipt_date]"
                                            data-id="0"
                                            class="form-control satisfactory_certificate_receipt_date satisfactory_certificate_receipt_date_0"
                                            placeholder="" autocomplete="off" readonly>
                                        <span class="text-danger error_satisfactory_certificate_receipt_date_0"></span>
                                    </td>
                                    <td>
                                        <input type="text" name="pro[0][invoice_receipt_date]" data-id="0"
                                            class="form-control invoice_receipt_date invoice_receipt_date_0"
                                            placeholder="" autocomplete="off" readonly>
                                        <span class="text-danger error_invoice_receipt_date_0"></span>
                                    </td>
                                    <td>
                                        <input type="text" name="pro[0][approval_of_payment_date]" data-id="0"
                                            class="form-control approval_of_payment_date approval_of_payment_date_0"
                                            placeholder="" autocomplete="off" readonly>
                                        <span class="text-danger error_approval_of_payment_date_0"></span>
                                    </td>

                                    <td>
                                        <input type="text" name="pro[0][payment_release_date]" data-id="0"
                                            class="form-control payment_release_date payment_release_date_0"
                                            placeholder="" autocomplete="off" readonly>
                                        <span class="text-danger error_payment_release_date_0"></span>

                                    </td>
                                    <td>
                                        <input type="text" name="pro[0][remarks_2]" data-id="0"
                                            class="form-control remarks_2 remarks_2_0" placeholder="" autocomplete="off">
                                        <span class="text-danger error_remarks_2_0"></span>

                                    </td>
                                    <td>
                                        <a href="javascript:void(0)" class="actionbtn remove_btn_fourth"
                                            data-id="0"><i class="fa-solid fa-trash-can"></i></a>
                                    </td>
                                </tr>
                            <?php endif; ?>


                        </tbody>
                        <tr>
                            <td colspan="14" class="text-end">
                                <button type="submit" class="btn btn-warning px-md-4">Save</button>
                            </td>
                        </tr>
                    </table>
                </div>
            </form>
        </div>
        <div class="manageTable my-5">
            <h3 class="d-flex justify-content-between flex-wrap align-items-center">
                STATUS OF PROCUREMENT OF SERVICES
                <button type="button" class="btn btn-outline-success fifth_form_add_btn">+ ADD</button>
            </h3>
            <form id="fifth_form">
                <div class="table-responsive">
                    <table class="table table-bordered  text-center">
                        <thead>
                            <tr>
                                <th rowSpan="2">SN.NO</th>
                                <th rowSpan="2" class="text-start">DETAILS OF SERVICES**</th>
                                <th rowspan="2" class="text-start">DATE OF EXPIRY OF EXISTING CONTRACT</th>
                                <th rowspan="2" class="text-start">VALUE OF EXISTING CONTRACT</th>
                                <th rowSpan="2" class="text-start">ESTIMATED VALUE OF NEW TENDER</th>
                                <th rowspan="2" class="text-start">TENDER TYPE (OPEN/ LIMITED/PAC)</th>
                                <th colspan="5">DATE OF</th>
                                <th rowspan="2">REMARKS</th>
                                <th rowspan="2">REMOVE</th>


                            </tr>
                            <tr>
                                <th>FLOATING TENDER</th>
                                <th>OPENING TENDER</th>
                                <th>TECH. EVAL.</th>
                                <th>FIN. EVAL.</th>
                                <th>AWARD OF WORK</th>


                            </tr>
                        </thead>
                        <tbody class="form_fifth_container">
                            <?php if($data_5->count()): ?>
                                <?php $__currentLoopData = $data_5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <script>
                                    selected_title_5.push("<?php echo e($value->title_id); ?>");
                                </script>
                                    <tr class="row_5_<?php echo e($key); ?>">
                                        <td><?php echo e($key + 1); ?></td>
                                        <td class="text-start">
                                            <input type="hidden" name="pro_services[<?php echo e($key); ?>][template_id]"
                                                value="<?php echo e($value->template_id); ?>">
                                            <input type="hidden" name="pro_services[<?php echo e($key); ?>][id]"
                                                value="<?php echo e($value->id); ?>">
                                            <select class="form-control title_id_five title_id_five_<?php echo e($key); ?>"
                                                name="pro_services[<?php echo e($key); ?>][title_id_five]"
                                                data-id="<?php echo e($key); ?>">
                                                <option selected disabled>Select</option>
                                                <?php $__currentLoopData = $fifth_form_title; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($k); ?>"
                                                        <?php if($k == $value->title_id): ?> selected <?php endif; ?>>
                                                        <?php echo e($val); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <span class="text-danger error_title_id_five_<?php echo e($key); ?>"></span>
                                        </td>


                                        <td>
                                            <input type="text"
                                                name="pro_services[<?php echo e($key); ?>][expiry_date_of_existing_contract]"
                                                value="<?php echo e(isset($value->expiry_date_of_existing_contract) ? date('d-m-Y', strtotime($value->expiry_date_of_existing_contract)) : ''); ?>"
                                                class="form-control service_expiry_date_of_existing_contract service_expiry_date_of_existing_contract_<?php echo e($key); ?>"
                                                placeholder="dd-mm-yyyy" readonly>
                                            <span
                                                class="text-danger error_service_expiry_date_of_existing_contract_<?php echo e($key); ?>"></span>
                                        </td>
                                        <td>
                                            <input type="number" step=any
                                                name="pro_services[<?php echo e($key); ?>][value_of_existing_contract]"
                                                value="<?php echo e($value->value_of_existing_contract ?? ''); ?>"
                                                class="form-control service_value_of_existing_contract service_value_of_existing_contract_<?php echo e($key); ?>"
                                                placeholder="" readonly>
                                            <span
                                                class="text-danger error_service_value_of_existing_contract_<?php echo e($key); ?>"></span>
                                        </td>
                                        <td>
                                            <input type="number" step=any
                                                name="pro_services[<?php echo e($key); ?>][estimated_value_of_new_tender]"
                                                value="<?php echo e($value->estimated_value_of_new_tender ?? ''); ?>"
                                                class="form-control service_estimated_value_of_new_tender service_estimated_value_of_new_tender_<?php echo e($key); ?>"
                                                placeholder="" autocomplete="off">
                                            <span
                                                class="text-danger error_service_estimated_value_of_new_tender_<?php echo e($key); ?>"></span>
                                        </td>
                                        <td>
                                            <select
                                                class="form-control service_tender_type service_tender_type_<?php echo e($key); ?>"
                                                name="pro_services[<?php echo e($key); ?>][tender_type]">
                                                <option selected disabled>Select</option>
                                                <option value="open"
                                                    <?php echo e($value->tender_type == 'open' ? 'selected' : ''); ?>>
                                                    <?php echo e(__('Open')); ?></option>
                                                <option value="limited"
                                                    <?php echo e($value->tender_type == 'limited' ? 'selected' : ''); ?>>
                                                    <?php echo e(__('Limited')); ?></option>
                                                <option value="pac"
                                                    <?php echo e($value->tender_type == 'pac' ? 'selected' : ''); ?>>
                                                    <?php echo e(__('PAC')); ?></option>

                                            </select>
                                            <span
                                                class="text-danger error_service_tender_type_<?php echo e($key); ?>"></span>
                                        </td>
                                        <td>
                                            <input type="text"
                                                name="pro_services[<?php echo e($key); ?>][floating_tender_date]"
                                                value="<?php echo e(isset($value->floating_tender_date) ? date('d-m-Y', strtotime($value->floating_tender_date)) : ''); ?>"
                                                data-id="<?php echo e($key); ?>"
                                                class="form-control service_floating_tender_date service_floating_tender_date_<?php echo e($key); ?>"
                                                placeholder="dd-mm-yyyy" autocomplete="off">
                                            <span
                                                class="text-danger error_service_floating_tender_date_<?php echo e($key); ?>"></span>
                                        </td>
                                        <td>
                                            <input type="text"
                                                name="pro_services[<?php echo e($key); ?>][opening_tender_date]"
                                                value="<?php echo e(isset($value->opening_tender_date) ? date('d-m-Y', strtotime($value->opening_tender_date)) : ''); ?>"
                                                data-id="<?php echo e($key); ?>"
                                                class="form-control service_opening_tender_date service_opening_tender_date_<?php echo e($key); ?>"
                                                placeholder="dd-mm-yyyy" readonly autocomplete="off">
                                            <span
                                                class="text-danger error_service_opening_tender_date_<?php echo e($key); ?>"></span>
                                        </td>
                                        <td>
                                            <input type="text"
                                                name="pro_services[<?php echo e($key); ?>][tech_eval_date]"
                                                value="<?php echo e(isset($value->tech_eval_date) ? date('d-m-Y', strtotime($value->tech_eval_date)) : ''); ?>"
                                                data-id="<?php echo e($key); ?>"
                                                class="form-control service_tech_eval_date service_tech_eval_date_<?php echo e($key); ?>"
                                                placeholder="dd-mm-yyyy" readonly autocomplete="off">
                                            <span
                                                class="text-danger error_service_tech_eval_date_<?php echo e($key); ?>"></span>
                                        </td>
                                        <td>
                                            <input type="text"
                                                name="pro_services[<?php echo e($key); ?>][final_eval_date]"
                                                value="<?php echo e(isset($value->final_eval_date) ? date('d-m-Y', strtotime($value->final_eval_date)) : ''); ?>"
                                                data-id="<?php echo e($key); ?>"
                                                class="form-control service_final_eval_date service_final_eval_date_<?php echo e($key); ?>"
                                                placeholder="dd-mm-yyyy" readonly autocomplete="off">
                                            <span
                                                class="text-danger error_service_final_eval_date_<?php echo e($key); ?>"></span>
                                        </td>
                                        <td>
                                            <input type="text"
                                                name="pro_services[<?php echo e($key); ?>][award_of_work_date]"
                                                value="<?php echo e(isset($value->award_of_work_date) ? date('d-m-Y', strtotime($value->award_of_work_date)) : ''); ?>"
                                                data-id="<?php echo e($key); ?>"
                                                class="form-control service_award_of_work_date service_award_of_work_date_<?php echo e($key); ?>"
                                                placeholder="dd-mm-yyyy" readonly autocomplete="off">
                                            <span
                                                class="text-danger error_service_award_of_work_date_<?php echo e($key); ?>"></span>
                                        </td>

                                        <td>
                                            <input type="text" name="pro_services[<?php echo e($key); ?>][remarks]"
                                                value="<?php echo e($value->remarks ?? ''); ?>"
                                                class="form-control service_remarks remarks_<?php echo e($key); ?>"
                                                placeholder="" autocomplete="off">
                                            <span class="text-danger error_service_remarks_<?php echo e($key); ?>"></span>

                                        </td>
                                        <td>
                                            <a href="javascript:void(0)" class="actionbtn remove_btn_fifth"
                                                data-id="<?php echo e($key); ?>" data-db_id="<?php echo e($value->id); ?>"><i class="fa-solid fa-trash-can"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr class="row_5_0">
                                    <td>01</td>
                                    <td class="text-start">
                                        <input type="hidden" name="pro_services[0][template_id]"
                                            value="<?php echo e($temp_id); ?>">
                                        <select class="form-control title_id_five title_id_five_0"
                                            name="pro_services[0][title_id_five]" data-id="0">
                                            <option selected disabled>Select</option>
                                            <?php $__currentLoopData = $fifth_form_title; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($k); ?>"><?php echo e($val); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <span class="text-danger error_title_id_five_0"></span>
                                    </td>


                                    <td>
                                        <input type="text" name="pro_services[0][expiry_date_of_existing_contract]"
                                            class="form-control service_expiry_date_of_existing_contract service_expiry_date_of_existing_contract_0"
                                            placeholder="dd-mm-yyyy" readonly>
                                        <span class="text-danger error_service_expiry_date_of_existing_contract_0"></span>
                                    </td>
                                    <td>
                                        <input type="number" step=any name="pro_services[0][value_of_existing_contract]"
                                            class="form-control service_value_of_existing_contract service_value_of_existing_contract_0"
                                            placeholder="" readonly>
                                        <span class="text-danger error_service_value_of_existing_contract_0"></span>
                                    </td>
                                    <td>
                                        <input type="number" step=any
                                            name="pro_services[0][estimated_value_of_new_tender]"
                                            class="form-control service_estimated_value_of_new_tender service_estimated_value_of_new_tender_0"
                                            placeholder="" autocomplete="off">
                                        <span class="text-danger error_service_estimated_value_of_new_tender_0"></span>
                                    </td>
                                    <td>
                                        <select class="form-control service_tender_type service_tender_type_0"
                                            name="pro_services[0][tender_type]">
                                            <option selected disabled>Select</option>
                                            <option value="open"><?php echo e(__('Open')); ?></option>
                                            <option value="limited"><?php echo e(__('Limited')); ?></option>
                                            <option value="pac"><?php echo e(__('PAC')); ?></option>

                                        </select>
                                        <span class="text-danger error_service_tender_type_0"></span>
                                    </td>
                                    <td>
                                        <input type="text" name="pro_services[0][floating_tender_date]" data-id="0"
                                            class="form-control service_floating_tender_date service_floating_tender_date_0"
                                            placeholder="dd-mm-yyyy" autocomplete="off">
                                        <span class="text-danger error_service_floating_tender_date_0"></span>
                                    </td>
                                    <td>
                                        <input type="text" name="pro_services[0][opening_tender_date]" data-id="0"
                                            class="form-control service_opening_tender_date service_opening_tender_date_0"
                                            placeholder="dd-mm-yyyy" readonly autocomplete="off">
                                        <span class="text-danger error_service_opening_tender_date_0"></span>
                                    </td>
                                    <td>
                                        <input type="text" name="pro_services[0][tech_eval_date]" data-id="0"
                                            class="form-control service_tech_eval_date service_tech_eval_date_0"
                                            placeholder="dd-mm-yyyy" readonly autocomplete="off">
                                        <span class="text-danger error_service_tech_eval_date_0"></span>
                                    </td>
                                    <td>
                                        <input type="text" name="pro_services[0][final_eval_date]" data-id="0"
                                            class="form-control service_final_eval_date service_final_eval_date_0"
                                            placeholder="dd-mm-yyyy" readonly autocomplete="off">
                                        <span class="text-danger error_service_final_eval_date_0"></span>
                                    </td>
                                    <td>
                                        <input type="text" name="pro_services[0][award_of_work_date]" data-id="0"
                                            class="form-control service_award_of_work_date service_award_of_work_date_0"
                                            placeholder="dd-mm-yyyy" readonly autocomplete="off">
                                        <span class="text-danger error_service_award_of_work_date_0"></span>
                                    </td>

                                    <td>
                                        <input type="text" name="pro_services[0][remarks]"
                                            class="form-control service_remarks remarks_0" placeholder=""
                                            autocomplete="off">
                                        <span class="text-danger error_service_remarks_0"></span>

                                    </td>
                                    <td>
                                        <a href="javascript:void(0)" class="actionbtn remove_btn_fifth" data-id="0"><i
                                                class="fa-solid fa-trash-can"></i></a>
                                    </td>
                                </tr>
                            <?php endif; ?>



                        </tbody>
                        <tr>
                            <td colspan="14" class="text-end">
                                <button type="submit" class="btn btn-warning px-md-4">Save</button>
                            </td>
                        </tr>
                    </table>
                </div>
            </form>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_specific_js'); ?>
    <script src="<?php echo e(asset('public/front/js/plugin/common.js')); ?>"></script>
    <script src="<?php echo e(asset('public/front/themes/js/jquery.dataTables.min.js')); ?>"></script>
    <script>
        var form_id = "<?php echo e($data->id ?? ''); ?>";
        var encode_temp_id = "<?php echo e(encode5t($temp_id)); ?>";
        var temp_id = "<?php echo e($temp_id); ?>";
        var form_third_count = "<?php echo e(isset($data_3) ? $data_3->count() : 0); ?>";
        var form_fourth_count = "<?php echo e(isset($data_4) ? $data_4->count() : 0); ?>";
        var form_fifth_count = "<?php echo e(isset($data_5) ? $data_5->count() : 0); ?>";

        var third_form_array_counting = [];
        var fourth_form_array_counting = [];
        var fifth_form_array_counting = [];

        if (form_third_count == 0) {
            var counting = 0;
            third_form_array_counting.push(0);
        } else {
            var counting = form_third_count * 1 - 1;
            for (let i = 0; i < form_third_count; i++) {
                third_form_array_counting.push(i);
            }
        }
        if (form_fourth_count == 0) {
            var counting_two = 0;
            fourth_form_array_counting.push(0);
        } else {
            var counting_two = form_fourth_count * 1 - 1;
            for (let i = 0; i < form_fourth_count; i++) {
                fourth_form_array_counting.push(i);
            }
        }
        if (form_fifth_count == 0) {
            var counting_fifth = 0;
            fifth_form_array_counting.push(0);
        } else {
            var counting_fifth = form_fifth_count * 1 - 1;
            for (let i = 0; i < form_fifth_count; i++) {
                fifth_form_array_counting.push(i);
            }
        }

        function getTitle(selected_title) {
            var title = '';
            <?php $__currentLoopData = $title_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                if (jQuery.inArray("<?php echo e($k); ?>", selected_title) == -1) {
                    title += '<option value="<?php echo e($k); ?>"><?php echo e($val); ?></option>';
                }
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            return title;
        }

        function getTitle2(selected_title_2) {
            var title = '';
            <?php $__currentLoopData = $title_list_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                if (jQuery.inArray("<?php echo e($k); ?>", selected_title_2) == -1) {
                    title += '<option value="<?php echo e($k); ?>"><?php echo e($val); ?></option>';
                }
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            return title;
        }
        function getTitle5(selected_title_5) {
            var title = '';
            <?php $__currentLoopData = $fifth_form_title; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                if (jQuery.inArray("<?php echo e($k); ?>", selected_title_5) == -1) {
                    title += '<option value="<?php echo e($k); ?>"><?php echo e($val); ?></option>';
                }
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            return title;
        }
    </script>







    <script src="<?php echo e(asset('public/front/js/manage/procurement_form_1.js')); ?>"></script>
    <script src="<?php echo e(asset('public/front/js/manage/procurement_form_2.js')); ?>"></script>
    <script src="<?php echo e(asset('public/front/js/manage/procurement_form_3.js')); ?>"></script>
    <script src="<?php echo e(asset('public/front/js/manage/procurement_form_4.js')); ?>"></script>
    <script src="<?php echo e(asset('public/front/js/manage/procurement_form_5.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rc_mt\resources\views/front/pages/manage/procurement/index.blade.php ENDPATH**/ ?>