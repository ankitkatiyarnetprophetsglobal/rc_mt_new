
<?php $__env->startSection('page_specific_css'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <form class="edit_template_management" action="<?php echo e(route('temp.manage.update')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row justify-content-md-end justify-content-center my-3">
                <div class="col-lg-12 col-md-12 col-12">
                    <div class="row align-items-center mb-2">
                        <div class="col-12">
                            <h3>Edit Template</h3>
                        </div>
                    </div>
                </div>
            </div>
            <div class="rc_forms row_0" id="template_management_form_container">
                <div class="row p-0 m-0 align-items-center">
                    <div class=" col-md-auto col-12 form-fields mb-4 ">
                        <fieldset>
                            <legend class="form_field_name"><span>TITLE/NAME OF TEMPLATE</span></legend>
                            <input type="hidden" name="id" value ="<?php echo e($data->id ?? ''); ?>">
                            <input type="text" class="form-control template_name" id="template_name"
                                name="template_name" aria-describedby="template name" autocomplete="off" value ="<?php echo e($data->name ?? ''); ?>">
                            <span class="text-danger error_template_name"></span>
                        </fieldset>
                    </div>
                    <div class=" col-md-auto col-12 form-fields mb-4  ">
                        <fieldset>
                            <legend class="form_field_name"><span>FROM  DATE</span></legend>
                            <input type="text" class="form-control from_date from_datepicker_0 edit_from_date" id="txtFrom" name="from_date" aria-describedby="from date" autocomplete="off" value ="<?php echo e(date('d-m-Y',strtotime($data->from_date)) ?? ''); ?>">
                            <span class="text-danger error_from_date"></span>
                        </fieldset>
                    </div>
                    <div class=" col-md-auto col-12 form-fields mb-4  ">
                        <fieldset>
                            <legend class="form_field_name"><span>TO  DATE</span></legend>
                            <input type="text" class="form-control to_date to_datepicker_0 edit_to_date" id="txtTo" name="to_date" aria-describedby="to date" autocomplete="off" value=<?php echo e(date('d-m-Y',strtotime($data->to_date))); ?>>
                            <span class="text-danger error_to_date"></span>
                        </fieldset>
                    </div>
                    <div class=" col-md-auto col-12 form-fields mb-4  ">
                        <fieldset>
                            <legend class="form_field_name"><span>REGIONAL CENTER</span></legend>
                            <?php 
                                $rc_id_array = explode(',', $data->rc_id); 
                                $rc_details = getRcList(); 
                            ?>
                            <select class="form-select regional_center_0 monthly_monitoring_regional_center_0 regional_center" id="regional_center" name="regional_center[]" aria-label="regional center" multiple="multiple" autocomplete="off">
                                <?php $__currentLoopData = $rc_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($val->user_id); ?>" <?php if(in_array($val->user_id,$rc_id_array)): ?> selected <?php endif; ?>><?php echo e($val->user_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="text-danger error_regional_center"></span>
                        </fieldset>
                    </div>
                    <div class="col-md-auto col-12 form-fields mb-4  ">
                        <fieldset>
                            <legend class="form_field_name"><span>TEMPLATE</span></legend>
                                <?php $temp_section_id_array = explode(',', $data->temp_section_id); ?>
                                <select class="form-select template monthly_monitoring_template_0" id="template" name="template[]" aria-label="regional center" multiple="multiple" autocomplete="off">

                                    <?php $__currentLoopData = $template_dropdown_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a_key => $a_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($a_key); ?>" <?php if(in_array($a_key,$temp_section_id_array)): ?> selected <?php endif; ?>><?php echo e($a_value); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            <span class="text-danger error_template"></span>
                        </fieldset>
                    </div>
                    <div class="col-md-auto col-12 form-fields mb-4  ">
                        <fieldset>
                            <legend class="form_field_name"><span>CATEGORIES</span></legend>
                              <select class="form-select categories monthly_monitoring_categories_0" id="monthly_categories" name="categories[]" multiple="multiple" autocomplete="off">                                
                                <option value="1" <?php echo e('1' == $data->categories_id ? 'selected' : 'disabled'); ?>>One time</option>                               
                              </select>
                            <span class="text-danger error_categories"></span>
                        </fieldset>
                    </div>
            </div>
            <div class="col-12 ">
                <button type="update" class="btn btn-warning px-md-4 inputDisabled">Update</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_specific_js'); ?>
   
    <script src="<?php echo e(asset('public/front/js/templatemanagement/templatemanagement.js')); ?>"></script>
    <script src="<?php echo e(asset('public/front/js/templatemanagement/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/front/js/templatemanagement/bootstrap-multiselect.js')); ?>"></script>

    <script>
      $(document).ready(function() {
        $('.monthly_monitoring_regional_center_0').multiselect({
          includeSelectAllOption: true,
        });
        $('.monthly_monitoring_template_0').multiselect({
          includeSelectAllOption: true,
        });
        $('.monthly_monitoring_categories_0').multiselect({
          includeSelectAllOption: true,
        });
     });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rc_mt\resources\views/admin/templatesMonitoring/edit.blade.php ENDPATH**/ ?>