<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('front.common.headers.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="fixed-navbar">
    <!-- Header -->
    <?php echo $__env->make('front.common.navbars.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Side Menu -->
    <?php echo $__env->make('front.common.sidebars.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Main Content -->
    <div class="app-content content">
        <div class="content-wrapper">
            <div class="content-body">

                <?php echo $__env->yieldContent('content'); ?>

            </div>
        </div>
    </div>
    <!--close main-content-->


    <div class="overlay"></div>

    <?php echo $__env->make('front.common.footers.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\rc_mt\resources\views/front/layouts/layout.blade.php ENDPATH**/ ?>