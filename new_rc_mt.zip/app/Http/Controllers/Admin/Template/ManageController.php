<?php

namespace App\Http\Controllers\Admin\Template;

use App\Http\Controllers\Controller;
use App\Models\Manage\Financemanages;
use App\Models\Manage\InfraWork;
use App\Models\Manage\ProcurementFirstForm;
use App\Models\Manage\ProcurementSecondForm;
use App\Models\Manage\ProcurementServiceForm;
use App\Models\Manage\ProcurementThirdForm;
use App\Models\RcDetail;
use App\Models\TempForRc;
use Illuminate\Http\Request;
use App\Models\Template;
use App\Models\TemplateSection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Models\Section;
use Illuminate\Support\Facades\Session;


class ManageController extends Controller
{

    public function index()
    {

        try {
             $user = Session::get('user');
             //dd($user);
        
            $templates = Template::with(['tempForRc']);
            if(Session::get('role_details')->id == 1){
                $templates = $templates->whereStatus(true)->pluck('name','id');
                $rc_ids = TempForRc::select(DB::raw('DISTINCT(rc_id)'))->pluck('rc_id')->toArray();
                $data = Template::with(['tempForRc', 'tempSection'])->whereStatus(true)->OrderBy('id', 'desc')->get();
            }else{
                $templates = $templates->whereHas('tempForRc',function($q) use($user){
                    $q->where('rc_id',$user->user_id);
                })->whereStatus(true)->pluck('name','id'); 
                $rc_ids = TempForRc::where('rc_id',$user->user_id)->pluck('rc_id')->toArray();  
                $data = Template::with(['tempForRc', 'tempSection'])->whereHas('tempForRc',function($q) use($user){
                    $q->where('rc_id',$user->user_id);
                })->whereStatus(true)->OrderBy('id', 'desc')->get();
            }
           $rc_details = collect(getRcList())->filter(function ($item) use($rc_ids) {
                if(in_array($item->user_id,$rc_ids)){
                    return $item;
                }
                
            })->values();
           return view('admin.templatesMonitoring.index', ['data' => $data, 'templates' => $templates,'rc_details' => $rc_details]);
        } catch (\Exception $ex) {

            $message = 'Somthing went wrong, Please try again...';
            return view('404_page', ['message' => $message, 'error_code' => 400]);
        }
    }


    public function rcWiseTemplate(Request $request)
    {
        try {
            $user = Session::get('user');
            //dd(date('Y-m-d',time()));
       
           $templates = Template::with(['tempForRc']);
           if(Session::get('role_details')->id == 1){
               $templates = $templates->whereStatus(true)->pluck('name','id');
               $rc_ids = TempForRc::select(DB::raw('DISTINCT(rc_id)'))->pluck('rc_id')->toArray();
            //    $data = Template::with(['tempForRc', 'tempSection'])->whereStatus(true)->OrderBy('id', 'desc')->get();
           }else{
               $templates = $templates->whereHas('tempForRc',function($q) use($user){
                   $q->where('rc_id',$user->user_id);
               })->whereStatus(true)->pluck('name','id'); 
               $rc_ids = TempForRc::where('rc_id',$user->user_id)->pluck('rc_id')->toArray();  
            //    $data = Template::with(['tempForRc', 'tempSection'])->whereHas('tempForRc',function($q) use($user){
            //        $q->where('rc_id',$user->user_id);
            //    })->whereStatus(true)->OrderBy('id', 'desc')->get();
           }
          $rc_details = collect(getRcList())->filter(function ($item) use($rc_ids) {
               if(in_array($item->user_id,$rc_ids)){
                   return $item;
               }
               
           })->values();

            $select_rc = decode5t($request->rc_id);

            $temp_ids = TempForRc::where('rc_id', decode5t($request->rc_id))->pluck('template_id');

            $filter_templates = Template::whereIn('id', $temp_ids)->get();

            return view('admin.templatesMonitoring.rc_templates', ['rc_details' => $rc_details, 'templates' => $templates, 'select_rc' => $select_rc, 'data' => $filter_templates]);
        } catch (\Exception $ex) {
            $message = 'Somthing went wrong !,Please try again...';
            return view('404_page', ['message' => $message, 'error_code' => 400]);
        }
    }
    public function templateWiseRc(Request $request) 
    {
        try {
            $user = Session::get('user');
            //dd($user);
       
            $templates = Template::with(['tempForRc']);
            if(Session::get('role_details')->id == 1){
               $templates = $templates->whereStatus(true)->pluck('name','id');
               $rc_ids = TempForRc::select(DB::raw('DISTINCT(rc_id)'))->pluck('rc_id')->toArray();
               $data = TempForRc::with('infraWork')->where('template_id', decode5t($request->temp_id))->get();
            }else{
               $templates = $templates->whereHas('tempForRc',function($q) use($user){
                   $q->where('rc_id',$user->user_id);
               })->whereStatus(true)->pluck('name','id'); 
               $rc_ids = TempForRc::where('rc_id',$user->user_id)->pluck('rc_id')->toArray();  
               $data = TempForRc::with(['infraWork','ProcurementFirstForm','ProcurementSecondForm','ProcurementThirdForm','ProcurementServiceForm'])
               ->where('template_id', decode5t($request->temp_id))->where('rc_id',$user->user_id)->get();
           }
           $rc_details = collect(getRcList())->filter(function ($item) use($rc_ids) {
               if(in_array($item->user_id,$rc_ids)){
                   return $item;
               }
               
           })->values();
            $select_temp = Template::find(decode5t($request->temp_id));
        return view('admin.templatesMonitoring.template_rc', ['rc_details' => $rc_details, 'templates' => $templates, 'select_temp' => $select_temp, 'data' => $data]);
        } catch (\Exception $ex) {
            $message = 'Somthing went wrong !,Please try again...';
            return view('404_page', ['message' => $message, 'error_code' => 400]);
        }
    }
    public function perticularTemp(Request $request)
    {
        
        try {
           

            // Dropdown list RC details
            $user = Session::get('user');
          $requested_rc = decode5t($request->rc_id);
          $requested_temp = decode5t($request->temp_id);
       
            $templates = Template::with(['tempForRc']);
            if(Session::get('role_details')->id == 1){
               $templates = $templates->whereStatus(true)->pluck('name','id');
               $rc_ids = TempForRc::select(DB::raw('DISTINCT(rc_id)'))->pluck('rc_id')->toArray();
               
            }else{
               $templates = $templates->whereHas('tempForRc',function($q) use($user){
                   $q->where('rc_id',$user->user_id);
               })->whereStatus(true)->pluck('name','id'); 
               $rc_ids = TempForRc::where('rc_id',$user->user_id)->pluck('rc_id')->toArray();  
               
           }

           $rc_details = collect(getRcList())->filter(function ($item) use($rc_ids) {
            if(in_array($item->user_id,$rc_ids)){
                return $item;
            }
            })->values();
            $select_temp = Template::find($requested_temp);
            $select_rc = decode5t($request->rc_id);


            $data = Template::with(['tempForRc'])->whereHas('tempForRc', function ($q) use ($request) {
                $q->where([['template_id', '=', decode5t($request->temp_id)], ['rc_id', '=', decode5t($request->rc_id)]]);
            })->find(decode5t($request->temp_id));

            if (!isset($data)) {
                Session::flash('error_message', 'This Combination Not Available.');
                return redirect()->route('temp.manage.index');
            }



            $select_rc_id = decode5t($request->rc_id);
            
            $template_accessible = Template::with(['tempSection.section'])->find($requested_temp);
            
           $infra_work = InfraWork::where('created_by',$requested_rc)->where('template_id',$requested_temp)->where('form_status',true)->count();
           $finance = Financemanages::where('created_by',$requested_rc)->where('template_id',$requested_temp)->where('status',true)->count();
           
           $procurement_first = ProcurementFirstForm::where('created_by',$requested_rc)->where('template_id',$requested_temp)->count();
           $procurement_second = ProcurementSecondForm::where('created_by',$requested_rc)->where('template_id',$requested_temp)->count();
           $procurement_third = ProcurementThirdForm::where('created_by',$requested_rc)->where('template_id',$requested_temp)->count();
           $procurement_fourth = ProcurementServiceForm::where('created_by',$requested_rc)->where('template_id',$requested_temp)->count();
           if($procurement_first && $procurement_second && $procurement_third && $procurement_fourth){
            $procurement = 1;
           }else{
            $procurement = 0;
           }
           $miscellaneous = 0;

            return view('admin.templatesMonitoring.rc_template_dashboard', 
            [
              'rc_details' => $rc_details,
              'templates' => $templates,
               'select_temp' => $select_temp,
               'select_rc' => $select_rc, 
               'select_rc_id' => $select_rc_id,
               'template_accessible' => $template_accessible,
               'infra_work' => $infra_work,
               'finance' => $finance,
               'procurement' => $procurement,
               'miscellaneous' => $miscellaneous
            ]);
        } catch (\Exception $ex) {
            $message = 'Somthing went wrong !,Please try again...';
            return view('404_page', ['message' => $message, 'error_code' => 400]);
        }
    }
    public function store(Request $request)
    {

        try {
            $validator = Validator::make($request->all(), [

                "monthly_monitoring.*.template_name"    => "required|unique:templates,name",
                "monthly_monitoring.*.from_date"    => "required",

            ], [

                'monthly_monitoring.*.template_name.required' => 'Please Enter Template Name',
                'monthly_monitoring.*.template_name.unique' => 'Template Name already exist',
                'monthly_monitoring.*.from_date.required' => 'Please Enter From Date',

            ]);

            if ($validator->fails()) {
                return response()->json(['success' => false, 'message' => $validator->errors()->first()]);
            }



            foreach ($request->monthly_monitoring as $value) {

                $regional_center = isset($value['regional_center']) && is_array($value['regional_center']) ? $value['regional_center'] : [];
                $regional_center_array = implode(',', $regional_center);
                $template = isset($value['template']) && is_array($value['template']) ? $value['template'] : [];
                $template_array = implode(',', $template);
                $categories = isset($value['categories']) && is_array($value['categories']) ? $value['categories'] : [];
                $categories_array = implode(',', $categories);

                $from_date = isset($value['from_date']) ? date('Y-m-d', strtotime($value['from_date'])) : null;
                $to_date = isset($value['to_date']) ? date('Y-m-d', strtotime($value['to_date'])) : null;

                $templates = new Template();
                $templates->name = $value['template_name'];
                $templates->from_date = $from_date;
                $templates->to_date = $to_date;
                $templates->rc_id = $regional_center_array;
                $templates->temp_section_id = $template_array;
                $templates->categories_id = $categories_array;
                $templates->status = true;
                $templates->created_by = Session::get('user')->user_id;
                $templates->save();

                foreach ($value['regional_center'] as $regional_center) {

                    $id = $templates->id;
                    $templaterc = new TempForRc();
                    $templaterc->template_id = $id;
                    $templaterc->rc_id = $regional_center;
                    $templaterc->save();
                }

                foreach ($value['template'] as $template) {

                    $id = $templates->id;
                    $temp_sections = new TemplateSection();
                    $temp_sections->template_id = $id;
                    $temp_sections->section_id = $template;
                    $temp_sections->save();
                }
            }

            Session::flash('message', 'Record Created.');
            return response()->json(['success' => true, 'message' => 'Data added successfully!']);
        } catch (\Exception $ex) {
            $message = 'Somthing went wrong !,Please try again...';
            return view('404_page', ['message' => $message, 'error_code' => 400]);
        }
    }
    public function create()
    {
        // dd(1321313);
        try {
            $template_data = Section::where([['status', '=', true]])->pluck('name', 'id');
            return view('admin.templatesMonitoring.create', ['template_data' => $template_data]);
        } catch (\Exception $th) {
            $message = 'Somthing went wrong !,Please try again...';
            return view('404_page', ['message' => $message, 'error_code' => 400]);
        }
    }

    public function deleteById($id)
    {
        try {
            $temp =  Template::findOrFail($id);
           
            if ($temp->delete()) {
                $trashTemp =  Template::onlyTrashed()->findOrFail($id);
                $trashTemp->deleted_by = Session::get('user')->user_id;
                $trashTemp->save();
                return response()->json(['status' => true, 'message' => 'Record deleted.']);
            }
            return response()->json(['status' => false, 'message' => 'Somthing went wrong']);
        } catch (\Exception $ex) {
           
            return response()->json(['status' => false, 'message' => 'Somthing went wrong']);
        }
    }

    public function edit($id)
    {
       try {
            $template_dropdown_data = Section::where([['status', '=', true]])->pluck('name', 'id');
            $templates_data = Template::whereStatus(true)->findOrFail(decode5t($id));
           return view('admin.templatesMonitoring.edit', ['data' => $templates_data, 'template_dropdown_data' => $template_dropdown_data]);
        } catch (\Exception $ex) {
            $message = 'Somthing went wrong !,Please try again...';
            return view('404_page', ['message' => $message, 'error_code' => 400]);
        }
    }

    public function update(Request $request)
    {

        $validator = Validator::make($request->all(), [

            "template_name"    => "required|unique:templates,name," . $request->id,
            "from_date"    => "required",

        ], [

            'template_name.required' => 'Please Enter Template Name',
            'template_name.unique' => 'Template Name already exist',
            'from_date.required' => 'Please Enter From Date',

        ]);

        if ($validator->fails()) {
            // dd($validator->errors()->first());
            // return response()->json(['success' => false, 'message' => $validator->errors()->first()]);
            return response()->json(['success' => false, 'error_message' => $validator->errors()->first()]);
        }
       $regional_center = isset($request->regional_center) && is_array($request->regional_center) ? $request->regional_center : [];
        $regional_center_array = implode(',', $regional_center);
        $template = isset($request->template) && is_array($request->template) ? $request->template : [];
        $template_array = implode(',', $template);
        $categories = isset($request->categories) && is_array($request->categories) ? $request->categories : [];
        $categories_array = implode(',', $categories);
        $from_date = isset($request->from_date) ? date('Y-m-d', strtotime($request->from_date)) : null;
        $to_date = isset($request->to_date) ? date('Y-m-d', strtotime($request->to_date)) : null;
        try {
            $template = Template::findOrFail($request->id);
            $template->name = $request->template_name;
            $template->from_date = $from_date;
            $template->to_date = $to_date;
            $template->rc_id = $regional_center_array;
            $template->temp_section_id = $template_array;
            $template->categories_id = $categories_array;
            $template->status = 1;
            $template->updated_by = Session::get('user')->user_id;
            $template->save();
            TempForRc::where('template_id', $request->id)->each(function ($data) {
                $data->delete();
            });

            TemplateSection::where('template_id', $request->id)->each(function ($data) {
                $data->delete();
            });

            foreach ($request['regional_center'] as $key => $regional_center) {

                $templaterc = new TempForRc();
                $templaterc->template_id = $template->id;
                $templaterc->rc_id = $regional_center;
                $templaterc->save();
            }

            foreach ($request['template'] as $key => $template_sec) {

                $temp_sections = new TemplateSection();
                $temp_sections->template_id = $template->id;
                $temp_sections->section_id = $template_sec;
                $temp_sections->save();
            }

            Session::flash('message', 'Record Updated.');
            return redirect()->route('temp.manage.index');
        } catch (\Exception $ex) {
            //throw $th;
        }
    }
}
