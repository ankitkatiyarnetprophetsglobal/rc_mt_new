
<?php $__env->startSection('page_specific_css'); ?>


    <link rel="stylesheet" href="<?php echo e(asset('public/front/themes/css/jquery.dataTables.min.css')); ?>">
    <script>
     var selected_title = [];
     var selected_title_2 = [];
     var selected_title_3 = [];
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="manageInfracture" autoComplete="off">
        <div class="manageTable">
           
            <div class="alert alert-success message d-none">
                <strong>Success!</strong> <?php echo e(Session::get('message')); ?>

            </div>
     
        
            <div class="alert alert-danger error_message d-none">
                <strong>Danger!</strong> <?php echo e(Session::get('error_message')); ?>

            </div>
       
            <h3 class="d-flex justify-content-between flex-wrap align-items-center">
                Status of Infra work upto Award of Tender
                <button type="button" class="btn btn-outline-success first_form_add_btn">+ ADD</button>
            </h3>
            <form class = "infra_manage_form">
                
                <div class="table-responsive">
                    <table class="table table-bordered  text-center">
                        <thead>
                            <tr>
                                <th rowSpan="2">SN.NO</th>
                                <th rowSpan="2">PROJECT ID / TITLE</th>
                                <th rowSpan="2">COST AS PER PE (IN CR.)</th>
                                <th rowSpan="2">DATE OF AA/ES</th>
                                <th rowSpan="2">AGENCY</th>
                                <th colSpan="5">DATE OF</th>
                                <th rowSpan="2">TENDER COST (IN CR.)</th>
                                <th rowSpan="2">REMARKS</th>
                                <th rowSpan="2">Remove</th>
                            </tr>
                            <tr>
                                
                                <th>TENDER FLOATED ON</th>
                                
                                 <th>BID SUBMISSION DEADLINE</th>
                                <th>TECH. BID OPENING</th>
                                <th>FIN. BID OPENING</th>
                                
                                <th>AWARDING OF CONTRACT</th>
                            </tr>
                        </thead>
                        <tbody class="form_first_container">
                            <?php if($data_1->count()): ?>
                           
                            <?php $__currentLoopData = $data_1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <script>
                            selected_title.push("<?php echo e($value->infra_id); ?>");
                        </script>
                            <tr class="row_<?php echo e($key); ?>">
                                <td><?php echo e($key + 1); ?></td>
                                <td>

                                    <input type="hidden" name="infra_manage[<?php echo e($key); ?>][id]" value="<?php echo e($value->id); ?>">
                                    <input type="hidden" name="infra_manage[<?php echo e($key); ?>][template_id]" value="<?php echo e($value->template_id); ?>">
                                    <select class="form-control project_title project_title_<?php echo e($key); ?>" data-id="<?php echo e($key); ?>" name ="infra_manage[<?php echo e($key); ?>][infra_id]" readonly>
                                       <option selected disabled>Project ID/Title</option>
                                       <?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_key => $p_val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($p_key); ?>" <?php echo e($p_key == $value->infrastructure->id ? 'selected' : 'disabled'); ?> ><?php echo e($p_val); ?></option>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <span class="text-danger error_project_title_<?php echo e($key); ?>"></span>
                                </td>
                                <td>
                                    <input type="text" class="form-control cost cost_0" placeholder="Cost" name ="infra_manage[<?php echo e($key); ?>][cost]" value="<?php echo e($value->infrastructure->cost); ?>" readonly>
                                    <span class="text-danger error_cost_<?php echo e($key); ?>"></span>
                                </td>
                                <td>
                                    <input type="text" class="form-control date date_<?php echo e($key); ?>" data-id="<?php echo e($key); ?>" name ="infra_manage[<?php echo e($key); ?>][date]" value="<?php echo e(date('d-m-Y',strtotime($value->infrastructure->date))); ?>" data-date = "<?php echo e($value->infrastructure->date); ?>" readonly>
                                    <span class="text-danger error_date_<?php echo e($key); ?>"></span>
                                </td>
                                <td>
                                    <input type="text" class="form-control agency_id agency_id_0" placeholder="Agency" name = "infra_manage[<?php echo e($key); ?>][agency_id]" value="<?php echo e($value->infrastructure->agency->name); ?>" autocomplete="off" readonly>
                                    <span class="text-danger error_agency_id_<?php echo e($key); ?>"></span>
                                </td>
                                <td>
                                    <input type="text" name="infra_manage[<?php echo e($key); ?>][date_of_issue]" value="<?php echo e(date('d-m-Y',strtotime($value->date_of_issue))); ?>" data-id = "<?php echo e($key); ?>" class="form-control date_of_issue date_of_issue_<?php echo e($key); ?>" placeholder="dd-mm-yyyy" autocomplete="off">
                                    <span class="text-danger error_date_of_issue_<?php echo e($key); ?>"></span>
                                </td>
                                <td>
                                    <input type="text" name ="infra_manage[<?php echo e($key); ?>][date_of_receipt]" value="<?php echo e(isset($value->date_of_receipt) ? date('d-m-Y',strtotime($value->date_of_receipt)) : ''); ?>" data-id = "<?php echo e($key); ?>" class="form-control date_of_receipt date_of_receipt_<?php echo e($key); ?>" placeholder="dd-mm-yyyy" readonly autocomplete="off">
                                    <span class="text-danger error_date_of_receipt_<?php echo e($key); ?>"></span>
                                </td>
                                <td>
                                    <input type="text" name ="infra_manage[<?php echo e($key); ?>][date_of_tech_bid]" value="<?php echo e(isset($value->date_of_tech_bid) ? date('d-m-Y',strtotime($value->date_of_tech_bid)) : ''); ?>" data-id = "<?php echo e($key); ?>" class="form-control date_of_tech_bid date_of_tech_bid_<?php echo e($key); ?>" placeholder="dd-mm-yyyy" readonly autocomplete="off">
                                    <span class="text-danger error_date_of_tech_bid_<?php echo e($key); ?>"></span>
                                </td>
                                <td>
                                    <input type="text" name ="infra_manage[<?php echo e($key); ?>][date_of_financial_bid]" value="<?php echo e(isset($value->date_of_financial_bid) ? date('d-m-Y',strtotime($value->date_of_financial_bid)) : ''); ?>" data-id = "<?php echo e($key); ?>" class="form-control date_of_financial_bid date_of_financial_bid_<?php echo e($key); ?>" placeholder="dd-mm-yyyy" readonly autocomplete="off">
                                    <span class="text-danger error_date_of_tech_bid_<?php echo e($key); ?>"></span>
                                </td>
                                <td>
                                    <input type="text" name ="infra_manage[<?php echo e($key); ?>][date_of_work_award]" value="<?php echo e(isset($value->date_of_work_award) ? date('d-m-Y',strtotime($value->date_of_work_award)) : ''); ?>" data-id = "<?php echo e($key); ?>" class="form-control date_of_work_award date_of_work_award_<?php echo e($key); ?>" placeholder="dd-mm-yyyy" readonly autocomplete="off">
                                    <span class="text-danger error_date_of_work_award_<?php echo e($key); ?>"></span>
                                </td>
                                <td>
                                    <input type="number" min="0" step=any name ="infra_manage[<?php echo e($key); ?>][tender_cost]"  value="<?php echo e(isset($value->tender_cost) ? $value->tender_cost : ''); ?>"  data-id = "<?php echo e($key); ?>" class="form-control tender_cost_<?php echo e($key); ?>" placeholder="Tender Cost" autocomplete="off">
                                    <span class="text-danger error_tender_cost_<?php echo e($key); ?>"></span>
                                </td>
                                <td>
                                    <input type="text" name ="infra_manage[<?php echo e($key); ?>][remarks_1]"  value="<?php echo e(isset($value->remarks_1) ? $value->remarks_1 : ''); ?>" class="form-control" class="form-control" placeholder="Remarks" autocomplete="off">
                                    <span class="text-danger error_remarks_1_<?php echo e($key); ?>"></span>
                                </td>
                                <td>
                                    
                                    <a href="#" class="actionbtn remove_btn" data-id="<?php echo e($key); ?>" data-db_id = "<?php echo e($value->id); ?>"><i class="fa-solid fa-trash-can"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?> 
                            <tr class="row_0">
                                <td>1</td>
                                <td>

                                    <input type="hidden" name="infra_manage[0][template_id]" value="<?php echo e($temp_id); ?>">
                                    <select class="form-control project_title project_title_0" data-id="0" name ="infra_manage[0][infra_id]" readonly autocomplete="off">
                                       <option selected disabled>Project ID/Title</option>
                                       <?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_key => $p_val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($p_key); ?>"><?php echo e($p_val); ?></option>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <span class="text-danger error_project_title_0"></span>
                                </td>
                                <td>
                                    <input type="text" class="form-control cost cost_0" placeholder="Cost" name ="infra_manage[0][cost]" readonly autocomplete="off">
                                    <span class="text-danger error_cost_0"></span>
                                </td>
                                <td>
                                    <input type="text" class="form-control date date_0" data-id="0" name ="infra_manage[0][date]" placeholder = "dd-mm-yyyy"  readonly autocomplete="off">
                                    <span class="text-danger error_date_0"></span>
                                </td>
                                <td>
                                    <input type="text" class="form-control agency agency_id_0" placeholder="Agency" name = "infra_manage[0][agency_id]"  readonly autocomplete="off">
                                    <span class="text-danger error_agency_id_0"></span>
                                </td>
                                <td>
                                    <input type="text" name="infra_manage[0][date_of_issue]" data-id = "0" class="form-control date_of_issue date_of_issue_0" placeholder="dd-mm-yyyy" autocomplete="off">
                                    <span class="text-danger error_date_of_issue_0"></span>
                                </td>
                                <td>
                                    <input type="text" name ="infra_manage[0][date_of_receipt]" data-id = "0" class="form-control date_of_receipt date_of_receipt_0" placeholder="dd-mm-yyyy" readonly autocomplete="off">
                                    <span class="text-danger error_date_of_receipt_0"></span>
                                </td>
                                <td>
                                    <input type="text" name ="infra_manage[0][date_of_tech_bid]" data-id = "0" class="form-control date_of_tech_bid date_of_tech_bid_0" placeholder="dd-mm-yyyy" readonly autocomplete="off">
                                    <span class="text-danger error_date_of_tech_bid_0"></span>
                                </td>
                                <td>
                                    <input type="text" name ="infra_manage[0][date_of_financial_bid]" data-id = "0" class="form-control date_of_financial_bid date_of_financial_bid_0" placeholder="dd-mm-yyyy" readonly autocomplete="off">
                                    <span class="text-danger error_date_of_tech_bid_0"></span>
                                </td>
                                <td>
                                    <input type="text" name ="infra_manage[0][date_of_work_award]" data-id = "0" class="form-control date_of_work_award date_of_work_award_0" placeholder="dd-mm-yyyy" readonly autocomplete="off">
                                    <span class="text-danger error_date_of_work_award_0"></span>
                                </td>
                                <td>
                                    <input type="number"  min="0" step=any name ="infra_manage[0][tender_cost]" data-id = "0" class="form-control tender_cost tender_cost_0" placeholder="Tender Cost" autocomplete="off">
                                    <span class="text-danger error_tender_cost_0"></span>
                                </td>
                                <td>
                                    <input type="text" name ="infra_manage[0][remarks_1]"  class="form-control" class="form-control" placeholder="Remarks" autocomplete="off">
                                    <span class="text-danger error_remarks_1_0"></span>
                                </td>
                                <td>
                                   
                                    <a href="#" class="actionbtn remove_btn" data-id="0" data-db_id = ""><i class="fa-solid fa-trash-can"></i></a>
                                </td>
                            </tr>

                            <?php endif; ?>
                            
                        </tbody>
                        <tr>
                            <td colspan="13" class="text-end"><button type="submit"
                                    class="btn btn-warning px-md-4">Save</button></td>
                        </tr>
                    </table>
                </div>
            </form>
        </div>
        <div class="manageTable mt-4">
            <h3 class="d-flex justify-content-between flex-wrap align-items-center">Status of Ongoing Infra Projects -
                Physical<button type="button" class="btn btn-outline-success second_form_add_btn">+ ADD</button></h3>
            <form class="infra_manage_form_two">
                <div class="table-responsive">
                    <table class="text-center table table-bordered">
                        <thead>
                            <tr>
                                <th>SN.NO</th>
                                <th>PROJECT ID / TITLE</th>
                                <th>AGENCY</th>
                                <th>COST</th>
                                <th>WORK START DATE</th>
                                <th>CONTRACTUAL PROBABLE DATE <br> OF COMPLETION (PDC)</th>
                                <th colspan="2">EXPECTED PROGRESS (DATE)</th>
                                <th>PROGRESS (IN %)</th>
                                <th>CURRENT PDC</th>
                                <th>REMARKS</th>
                                <th>Remove</th>
                            </tr>
                        </thead>
                        <tbody class = "form_second_container">
                           
                            <?php if($data_2->count()): ?>
                            <?php $__currentLoopData = $data_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <script>
                                selected_title_2.push("<?php echo e($value->infra_id); ?>");
                            </script>
                            <tr class="row_two_<?php echo e($key); ?>">
                                <input type="hidden" name="infra_manage_two[<?php echo e($key); ?>][template_id]" value="<?php echo e($value->template_id); ?>">
                                <input type="hidden" name="infra_manage_two[<?php echo e($key); ?>][id]" value="<?php echo e($value->id); ?>">
                                <td rowspan="3"><?php echo e($key+1); ?></td>
                                <td rowspan="3">
                                    <select class="form-control project_title_two project_title_two_<?php echo e($key); ?>" name="infra_manage_two[<?php echo e($key); ?>][infra_id]" data-id="<?php echo e($key); ?>" autocomplete="off">
                                        <option selected disabled>Project ID/Title</option>
                                        <?php $__currentLoopData = $project_two; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_key => $p_val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <option value="<?php echo e($p_key); ?>" <?php echo e($p_key == $value->infrastructure->id ? 'selected' : 'disabled'); ?>><?php echo e($p_val); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <span class="text-danger error_project_title_two_<?php echo e($key); ?>"></span>
                                </td>
                                <td rowspan="3">
                                    <input type="text" class="form-control agency_id_two agency_id_two_<?php echo e($key); ?>" placeholder="Agency" name = "infra_manage_two[<?php echo e($key); ?>][agency_id]" value="<?php echo e($value->infrastructure->agency->name ?? ''); ?>"  readonly autocomplete="off">
                                    <span class="text-danger error_agency_id_two_<?php echo e($key); ?>"></span>
                                </td>
                                <td rowspan="3">
                                    <input type="text" class="form-control cost_two cost_two_<?php echo e($key); ?>" placeholder="Cost" name ="infra_manage_two[<?php echo e($key); ?>][cost]" value="<?php echo e($value->infrastructure->cost ?? ''); ?>" readonly autocomplete="off">
                                    <span class="text-danger error_cost_<?php echo e($key); ?>"></span>
                                </td>
                                <td rowspan="3">
                                    <input type="text"  class="form-control work_start_date work_start_date_<?php echo e($key); ?>" data-id="<?php echo e($key); ?>" name="infra_manage_two[<?php echo e($key); ?>][work_start_date]" value="<?php echo e(isset($value->work_start_date) ? date('d-m-Y',strtotime($value->work_start_date)) : ''); ?>" placeholder="dd-mm-yyyy" readonly autocomplete="off">
                                    <span class="text-danger error_work_start_date_<?php echo e($key); ?>"></span>
                                </td>
                                <td rowspan="3">
                                    <input type="text" class="form-control cpdc_date cpdc_date_<?php echo e($key); ?>" data-id ="<?php echo e($key); ?>" name="infra_manage_two[<?php echo e($key); ?>][cpdc_date]" value="<?php echo e(isset($value->cpdc_date) ? date('d-m-Y',strtotime($value->cpdc_date)) : ''); ?>" placeholder="dd-mm-yyyy" readonly autocomplete="off">
                                    <span class="text-danger error_cpdc_date_<?php echo e($key); ?>"></span>
                                </td>
                                <td>25%</td>
                                <td>
                                    <input type="text" class="form-control epd_25 epd_25_<?php echo e($key); ?>" data-id = "<?php echo e($key); ?>" name="infra_manage_two[<?php echo e($key); ?>][epd_25]" value="<?php echo e(isset($value->epd_25) ? date('d-m-Y',strtotime($value->epd_25)) : ''); ?>" placeholder="dd-mm-yyyy" readonly autocomplete="off">
                                    <span class="text-danger error_epd_25_<?php echo e($key); ?>"></span>
                                </td>
                                <td rowspan="3">
                                    <input placeholder="Progress %" type="text" name="infra_manage_two[<?php echo e($key); ?>][progress_percentage]" class="form-control progress_percentage progress_percentage_<?php echo e($key); ?>" value="<?php echo e($value->progress_percentage ?? ''); ?>" autocomplete="off">
                                    <span class="text-danger error_progress_percentage_<?php echo e($key); ?>"></span>
                                </td>
                                <td rowspan="3">
                                    <input placeholder="Current PDC" type="text" class="form-control current_pdc current_pdc_<?php echo e($key); ?>" name="infra_manage_two[<?php echo e($key); ?>][current_pdc]" value="<?php echo e($value->current_pdc ?? ''); ?>" autocomplete="off">
                                    <span class="text-danger error_current_pdc_<?php echo e($key); ?>"></span>
                                </td>
                                <td rowspan="3">
                                    <input placeholder="Remark" type="text" class="form-control remarks_2 remarks_2_<?php echo e($key); ?>" name="infra_manage_two[<?php echo e($key); ?>][remarks_2]" value="<?php echo e($value->remarks_2 ?? ''); ?>" autocomplete="off">
                                    <span class="text-danger error_remarks_2_<?php echo e($key); ?>"></span>
                                </td>
                                <td rowspan="3">
                                    <a href="javascript:void(0)" class="actionbtn remove_btn_two" data-id="<?php echo e($key); ?>" data-db_id = "<?php echo e($value->id); ?>"><i class="fa-solid fa-trash-can"></i></a>
                                </td>
                            </tr>
                            <tr class="row_two_<?php echo e($key); ?>">
                                <td>50%</td>
                                <td>
                                    <input type="text" class="form-control epd_50 epd_50_<?php echo e($key); ?>" data-id = "<?php echo e($key); ?>" name="infra_manage_two[<?php echo e($key); ?>][epd_50]" value="<?php echo e(isset($value->epd_50) ? date('d-m-Y',strtotime($value->epd_50)) : ''); ?>" placeholder="dd-mm-yyyy" readonly autocomplete="off">
                                    <span class="text-danger error_epd_50_<?php echo e($key); ?>"></span>
                                </td>
                            </tr>
                            <tr class="row_two_<?php echo e($key); ?> last_tr">
                                <td>75%</td>
                                <td>
                                    <input type="text" class="form-control epd_75 epd_75_<?php echo e($key); ?>" data-id = "<?php echo e($key); ?>" name="infra_manage_two[<?php echo e($key); ?>][epd_75]" value="<?php echo e(isset($value->epd_75) ? date('d-m-Y',strtotime($value->epd_75)) : ''); ?>" placeholder="dd-mm-yyyy" readonly autocomplete="off">
                                    <span class="text-danger error_epd_75_<?php echo e($key); ?>"></span>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?> 
                            <tr class="row_two_0">
                                <td rowspan="3">1</td>
                                <td rowspan="3">
                                    <input type="hidden" name="infra_manage_two[0][template_id]" value="<?php echo e($temp_id); ?>">
                                    <select class="form-control project_title_two project_title_two_0" name="infra_manage_two[0][infra_id]" data-id="0" autocomplete="off">
                                        <option selected disabled>Project ID/Title</option>
                                        <?php $__currentLoopData = $project_two; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_key => $p_val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <option value="<?php echo e($p_key); ?>"><?php echo e($p_val); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <span class="text-danger error_project_title_two_0"></span>
                                </td>
                                <td rowspan="3">
                                    <input type="text" class="form-control agency_id_two agency_id_two_0" placeholder="Agency" name = "infra_manage_two[0][agency_id]"  readonly autocomplete="off">
                                    <span class="text-danger error_agency_id_two_0"></span>
                                </td>
                                <td rowspan="3">
                                    <input type="text" class="form-control cost_two cost_two_0" placeholder="Cost" name ="infra_manage_two[0][cost]"  readonly autocomplete="off">
                                    <span class="text-danger error_cost_0"></span>
                                </td>
                                <td rowspan="3">
                                    <input type="text"  class="form-control work_start_date work_start_date_0" data-id ="0" name="infra_manage_two[0][work_start_date]" placeholder="dd-mm-yyyy" readonly autocomplete="off">
                                    <span class="text-danger error_work_start_date_0"></span>
                                </td>
                                <td rowspan="3">
                                    <input type="text" class="form-control cpdc_date cpdc_date_0" data-id = "0" name="infra_manage_two[0][cpdc_date]" placeholder="dd-mm-yyyy" readonly autocomplete="off">
                                    <span class="text-danger error_cpdc_date_0"></span>
                                </td>
                                <td>25%</td>
                                <td>
                                    <input type="text" class="form-control epd_25 epd_25_0" data-id = "0" name="infra_manage_two[0][epd_25]" placeholder="dd-mm-yyyy" readonly autocomplete="off">
                                    <span class="text-danger error_epd_25_0"></span>
                                </td>
                                <td rowspan="3">
                                    <input placeholder="Progress %" type="text" name="infra_manage_two[0][progress_percentage]" class="form-control" autocomplete="off">
                                    <span class="text-danger error_progress_percentage_0"></span>
                                </td>
                                <td rowspan="3">
                                    <input placeholder="Current PDC" type="text" class="form-control current_pdc current_pdc_0" name="infra_manage_two[0][current_pdc]" autocomplete="off">
                                    <span class="text-danger error_current_pdc_0"></span>
                                </td>
                                <td rowspan="3">
                                    <input placeholder="Remark" type="text" class="form-control remarks_2 remarks_2_0" name="infra_manage_two[0][remarks_2]" autocomplete="off">
                                    <span class="text-danger error_remarks_2_0"></span>
                                </td>
                                <td rowspan="3">
                                   <a href="javascript:void(0)" class="actionbtn remove_btn_two" data-id="0" data-db_id = ""><i class="fa-solid fa-trash-can"></i></a>
                                </td>
                            </tr>
                            <tr class="row_two_0">
                                <td>50%</td>
                                <td>
                                    <input type="text" class="form-control epd_50 epd_50_0" data-id = "0" name="infra_manage_two[0][epd_50]" placeholder="dd-mm-yyyy" readonly autocomplete="off">
                                    <span class="text-danger error_epd_50_0"></span>
                                </td>
                            </tr>
                            <tr class="row_two_0 last_tr">
                                <td>75%</td>
                                <td>
                                    <input type="text" class="form-control epd_75 epd_75_0" data-id = "0" name="infra_manage_two[0][epd_75]" placeholder="dd-mm-yyyy" readonly autocomplete="off">
                                    <span class="text-danger error_epd_75_0"></span>
                                </td>
                            </tr>
                            <?php endif; ?>
                           
                        </tbody>
                        <tr>
                            <td colspan="12" class="text-end">
                                <button type="submit" class="btn btn-warning px-md-4">Save</button>
                            </td>
                        </tr>
                    </table>
                </div>
            </form>
        </div>
        <div class="manageTable mt-4 mb-3">
            <h3 class="d-flex justify-content-between flex-wrap align-items-center">Status of Ongoing infra projects -
                Financial<button type="button" class="btn btn-outline-success third_form_add_btn">+ ADD</button></h3>
            <form class="infra_manage_form_three">
                <div class="table-responsive">
                    <table class="text-center table table-bordered">
                        <thead>
                            <tr>
                                <th>SN.NO</th>
                                <th>PROJECT ID / TITLE</th>
                                <th>AGENCY</th>
                                <th>TENDER COST <br> (IN CR.)</th>
                                <th>FUND RELEASED TILL DATE <br> (TO AGENCY) (IN CR.)</th>
                                <th>FUNDS / PERCENTAGE OF <br> FUNDS UTILISED</th>
                                <th>UC STATUS</th>
                            </tr>
                        </thead>
                        <tbody class="form_third_container">
                           <?php if($data_3->count()): ?>
                           <?php $__currentLoopData = $data_3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <script>
                            selected_title_3.push("<?php echo e($value->infra_id); ?>");
                         </script>
                           <tr class="row_three_<?php echo e($key); ?>">
                            <input type="hidden" name="infra_manage_three[<?php echo e($key); ?>][id]" value="<?php echo e($value->id); ?>">
                            <td><?php echo e($key+1); ?></td>
                            <td>
                                <input type="hidden" name="infra_manage_three[<?php echo e($key); ?>][template_id]" value="<?php echo e($value->template_id); ?>">
                                <select class="form-select project_title_three project_title_three_<?php echo e($key); ?>" name="infra_manage_three[<?php echo e($key); ?>][infra_id]"  data-id="<?php echo e($key); ?>" autocomplete="off">
                                    <option selected disabled>Project ID/Title</option>
                                    <?php $__currentLoopData = $project_three; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_key => $p_val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <option value="<?php echo e($p_key); ?>" <?php echo e($p_key == $value->infrastructure->id ? 'selected' : 'disabled'); ?>><?php echo e($p_val); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text-danger error_project_title_three_<?php echo e($key); ?>"></span>
                            </td>
                            <td>
                                <input type="text" class="form-control agency_id_three agency_id_three_<?php echo e($key); ?>" placeholder="Agency" name = "infra_manage_three[<?php echo e($key); ?>][agency_id]" value="<?php echo e($value->infrastructure->agency->name ?? ''); ?>"  readonly autocomplete="off">
                                <span class="text-danger error_agency_id_three_<?php echo e($key); ?>"></span>
                            </td>
                            <td>
                                <input type="text" class="form-control cost_three cost_three_<?php echo e($key); ?>" placeholder="Cost" name ="infra_manage_three[<?php echo e($key); ?>][cost]" value="<?php echo e($value->infrastructure->cost ?? ''); ?>"  readonly autocomplete="off">
                                <span class="text-danger error_cost_three_<?php echo e($key); ?>"></span>
                            </td>
                            <td>
                                <input placeholder="Fund Release" type="text" class="form-control fund_release fund_release_<?php echo e($key); ?>" name ="infra_manage_three[<?php echo e($key); ?>][fund_release]" value="<?php echo e($value->fund_release ?? ''); ?>" autocomplete="off">
                                <span class="text-danger error_fund_release_<?php echo e($key); ?>"></span>
                            </td>
                            <td>
                                <input placeholder="Fund/Percentage" type="text" class="form-control utilised_fund_percentage utilised_fund_percentage_<?php echo e($key); ?>" name ="infra_manage_three[<?php echo e($key); ?>][utilised_fund_percentage]" value="<?php echo e($value->utilised_fund_percentage ?? ''); ?>" autocomplete="off">
                                <span class="text-danger error_utilised_fund_percentage_<?php echo e($key); ?>"></span>
                            </td>
                            <td>
                                <select class="form-control uc_status uc_status_<?php echo e($key); ?>" name ="infra_manage_three[<?php echo e($key); ?>][uc_status]">
                                    <option selected disabled> Select UC Status </option>
                                    <option value="1" <?php echo e(($value->uc_status == 1 ? 'selected' : '')); ?>>Submitted</option>
                                    <option value="0" <?php echo e(($value->uc_status == 0 ? 'selected' : '')); ?>>Pending</option>
                                </select>
                                <span class="text-danger error_uc_status_<?php echo e($key); ?>"></span>
                            </td>
                            <td>
                               
                                <a href="javascript:void(0)" class="actionbtn remove_btn_three" data-id="<?php echo e($key); ?>" data-db_id = "<?php echo e($value->id); ?>"><i class="fa-solid fa-trash-can"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <?php else: ?> 
                           <tr class="row_three_0">
                            <td>1</td>
                            <td>
                                <input type="hidden" name="infra_manage_three[0][template_id]" value="<?php echo e($temp_id); ?>">
                                <select class="form-select project_title_three project_title_three_0" name="infra_manage_three[0][infra_id]"  data-id="0" autocomplete="off">
                                    <option selected disabled>Project ID/Title</option>
                                    <?php $__currentLoopData = $project_three; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_key => $p_val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <option value="<?php echo e($p_key); ?>"><?php echo e($p_val); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text-danger error_project_title_three_0"></span>
                            </td>
                            <td>
                                <input type="text" class="form-control agency_id_three agency_id_three_0" placeholder="Agency" name = "infra_manage_three[0][agency_id]"  readonly autocomplete="off">
                                <span class="text-danger error_agency_id_three_0"></span>
                            </td>
                            <td>
                                <input type="text" class="form-control cost_three cost_three_0" placeholder="Cost" name ="infra_manage_three[0][cost]"  readonly autocomplete="off">
                                <span class="text-danger error_cost_three_0"></span>
                            </td>
                            <td>
                                <input placeholder="Fund Release" type="text" class="form-control fund_release fund_release_0" name ="infra_manage_three[0][fund_release]" autocomplete="off">
                                <span class="text-danger error_fund_release_0"></span>
                            </td>
                            <td>
                                <input placeholder="Fund/Percentage" type="text" class="form-control utilised_fund_percentage utilised_fund_percentage_0" name ="infra_manage_three[0][utilised_fund_percentage]" autocomplete="off">
                                <span class="text-danger error_utilised_fund_percentage_0"></span>
                            </td>
                            <td>
                                <select class="form-control uc_status uc_status_0" name ="infra_manage_three[0][uc_status]">
                                    <option selected disabled> Select UC Status </option>
                                    <option value="1">Submitted</option>
                                    <option value="0">Pending</option>
                                </select>
                                <span class="text-danger error_uc_status_0"></span>
                            </td>
                            <td>
                               
                                <a href="javascript:void(0)" class="actionbtn remove_btn_three" data-id="0" data-db_id = "0"><i class="fa-solid fa-trash-can"></i></a>
                            </td>
                        </tr>
                           <?php endif; ?>
                            
                        </tbody>
                        <tr>
                            <td colspan="8" class="text-start"><span class="ps-1">Total</span></td>
                        </tr>
                        <tr>
                            <td colspan="8" class="text-end">
                                <button type="submit" class="btn btn-warning px-md-4">Save</button>
                            </td>
                        </tr>
                    </table>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_specific_js'); ?>
    
    <script src="<?php echo e(asset('public/front/js/plugin/common.js')); ?>"></script>
    <script src="<?php echo e(asset('public/front/themes/js/jquery.dataTables.min.js')); ?>"></script>
    
    <script>
        var temp_id = "<?php echo e($temp_id); ?>";
        var encode_temp_id = "<?php echo e(encode5t($temp_id)); ?>";
        $(document).ready(function() {
         $('#masterInfra').DataTable({});
        });
        
        var form_first_count = "<?php echo e($data_1->count()); ?>";
        var form_second_count = "<?php echo e($data_2->count()); ?>";
        var form_third_count = "<?php echo e($data_3->count()); ?>";
        var first_form_array_counting = [];
        var second_form_array_counting = [];
        var third_form_array_counting = [];
        if(form_first_count == 0){
            var counting = 0;
           first_form_array_counting.push(0);
        }else{
            var counting = form_first_count*1 - 1; 
            for(let i = 0; i < form_first_count ;i++){
                first_form_array_counting.push(i);
            }
        }
        if(form_second_count == 0){
            var counting_2 = 0;
            second_form_array_counting.push(0);
        }else{
            var counting_2 = form_second_count*1 - 1;
            for(let i = 0; i < form_second_count ;i++){
                second_form_array_counting.push(i);
            }
        }
        if(form_third_count == 0){
            var counting_3 = 0;
            third_form_array_counting.push(0);
        }else{
            var counting_3 = form_third_count*1 - 1;
            for(let i = 0; i < form_third_count ;i++){
                third_form_array_counting.push(i);
            }
        }
        function getProjectTitle(selected_title){
        var project_title = '';
        <?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_key => $p_val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
           if(jQuery.inArray("<?php echo e($p_key); ?>", selected_title) == -1){
                project_title += '<option value="<?php echo e($p_key); ?>"><?php echo e($p_val); ?></option>';
            }
       
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         return project_title;
        }
        //console.log("first - "+selected_title_2);
        function getProjectTitle2(selected_title_2){
        var project_title_2 = '';
        <?php $__currentLoopData = $project_two; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_key => $p_val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             // console.log("<?php echo e($p_key); ?>");
           if(jQuery.inArray("<?php echo e($p_key); ?>", selected_title_2) == -1){
                project_title_2 += '<option value="<?php echo e($p_key); ?>"><?php echo e($p_val); ?></option>';
            }
       
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         return project_title_2;
        }
        var project_title_3 = '';
        function getProjectTitle3(selected_title_3){
        var project_title_3 = '';
        <?php $__currentLoopData = $project_three; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_key => $p_val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             // console.log("<?php echo e($p_key); ?>");
           if(jQuery.inArray("<?php echo e($p_key); ?>", selected_title_3) == -1){
                project_title_3 += '<option value="<?php echo e($p_key); ?>"><?php echo e($p_val); ?></option>';
            }
       
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         return project_title_3;
        }
        
    </script>
    <script src="<?php echo e(asset('public/front/js/manage/infra_form_1.js')); ?>"></script>
    <script src="<?php echo e(asset('public/front/js/manage/infra_form_2.js')); ?>"></script>
    <script src="<?php echo e(asset('public/front/js/manage/infra_form_3.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rc_mt\resources\views/front/pages/manage/infrastructure/index.blade.php ENDPATH**/ ?>