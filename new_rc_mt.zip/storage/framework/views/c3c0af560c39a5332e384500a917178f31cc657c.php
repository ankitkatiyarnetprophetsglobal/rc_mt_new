<aside class="main-menu menu-fixed">
    <div class="navbar-header">
        <a href="#" class="l_left_logo">
            <img src="<?php echo e(asset('public/front/themes/images/logo.svg')); ?>" alt="" class="img-fluid">
        </a>
    </div>
    <div class="main-menu-content">
        <ul class="navigation navigation-main" id="main-menu-navigation">
            <li class="nav-item active"><a href="<?php echo e(url('/')); ?>"><i class="icon-DASHBOARD"></i><span
                        class="menu-title">DASHBOARD</span></a>
            </li>
            <?php if(Session::get('role_details')->id == 1): ?>
            <li class="nav-item has-sub">
                <a href="javascript:void(0)" class="link"><i class="icon-MANAGE"></i><span class="menu-title">
                        Master</span></a>
                <ul class="menu-content submenu">
                    <li><a class="menu-item" href="<?php echo e(route('infrastructure.index')); ?>"><span class="menu-title">Infra structure</a></span> </li>
                    <li><a class="menu-item" href="<?php echo e(route('finance.index')); ?>"><span class="menu-title">Finances</a></span> </li>
                    <li><a class="menu-item" href="<?php echo e(route('masters.miscmaster.index')); ?>"><span class="menu-title">Miscellaneous</a></span> </li>
                    <li><a class="menu-item" href="<?php echo e(route('procurement.index')); ?>"><span class="menu-title">Procurement</a></span> </li>
                    <li><a class="menu-item" href="<?php echo e(route('procurement.service.index')); ?>"><span class="menu-title">Procurement Services</a></span> </li>
                  </ul>
            </li>
            <?php endif; ?>
            
            <li class="nav-item"><a href="<?php echo e(route('temp.manage.index')); ?>"><i class="icon-MONTHLY-MONITORING"></i><span
                        class="menu-title">Monthly Monitoring</span></a>
            </li>
            <li class="nav-item"><a href="javascript:void(0)"><i class="icon-TENDER"></i><span
                        class="menu-title">TENDER</span></a>
            </li>


            <!-- <li class="nav-item has-sub">
      <a href="#" class="link"><i class="fa fa-question-circle-o"></i><span class="menu-title">Lorem
          Ipsum</span></a>
      <ul class="menu-content submenu">
        <li><a class="menu-item" href="registration.html">Lorem Ipsum</a> </li>
        <li><a class="menu-item" href="#">Lorem Ipsum</a> </li>
      </ul>
    </li>
    <li class="nav-item has-sub">
      <a href="#" class="link"><i class="fa fa-question-circle-o"></i><span class="menu-title">Lorem
          Ipsum</span></a>
      <ul class="menu-content submenu">
        <li><a class="menu-item" href="#">Lorem Ipsum</a> </li>
        <li><a class="menu-item" href="#">Lorem Ipsum</a> </li>
      </ul>
    </li> -->
        </ul>
    </div>
</aside>
<?php /**PATH C:\xampp\htdocs\rc_mt\resources\views/front/common/sidebars/sidebar.blade.php ENDPATH**/ ?>